Blyx library logos

Each PNG is a 320 by 320 pixel transparent illustration of the Blyx penguin performing one library task. Filenames match library slugs. Open https://www.blyx-lang.space/packages/ followed by a slug for code and examples.

Gallery: https://www.blyx-lang.space/libraries/logos
Project: Rahul Chaube and the Blyx ecosystem
library-logo-prompts.json records the design brief and accessible description for each illustration. SHA256SUMS lists the PNG checksums. The project license texts are included.
