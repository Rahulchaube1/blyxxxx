# Framework bird logo prompts

## swiftlet

Logo-brand for an open-source Blyx programming framework. A swiftlet with sweeping midnight-blue wing-like head stripes and a forked dark silhouette, icy blue cheek. Create one original mascot as a crisp three-quarter bird bust looking right. Distinctive species anatomy, intelligent friendly expression, clear bold dark outlines, restrained flat colors, and a strong silhouette legible as a 48-pixel icon, visually related to a graphic bird mascot family. Square canvas, center mark with comfortable breathing room, fully transparent background; no lettering, no emblem, no scenery, no shadows or gradients.

## shrike

Logo-brand for an open-source Blyx programming framework. A gray shrike with its distinctive dark eye mask and a muted lilac nape, hooked beak. Create one original mascot as a crisp three-quarter bird bust looking right. Distinctive species anatomy, intelligent friendly expression, clear bold dark outlines, restrained flat colors, and a strong silhouette legible as a 48-pixel icon, visually related to a graphic bird mascot family. Square canvas, center mark with comfortable breathing room, fully transparent background; no lettering, no emblem, no scenery, no shadows or gradients.

## bunting

Logo-brand for an open-source Blyx programming framework. A painted bunting with a sapphire crown, vermilion chest patch and pale green shoulder. Create one original mascot as a crisp three-quarter bird bust looking right. Distinctive species anatomy, intelligent friendly expression, clear bold dark outlines, restrained flat colors, and a strong silhouette legible as a 48-pixel icon, visually related to a graphic bird mascot family. Square canvas, center mark with comfortable breathing room, fully transparent background; no lettering, no emblem, no scenery, no shadows or gradients.

## wren

Logo-brand for an open-source Blyx programming framework. A small rust-brown wren with a cream eyebrow and short slender beak, alert curious face. Create one original mascot as a crisp three-quarter bird bust looking right. Distinctive species anatomy, intelligent friendly expression, clear bold dark outlines, restrained flat colors, and a strong silhouette legible as a 48-pixel icon, visually related to a graphic bird mascot family. Square canvas, center mark with comfortable breathing room, fully transparent background; no lettering, no emblem, no scenery, no shadows or gradients.

## weaver

Logo-brand for an open-source Blyx programming framework. A golden village weaver with a bold charcoal face and short cone-shaped bill, amber hood. Create one original mascot as a crisp three-quarter bird bust looking right. Distinctive species anatomy, intelligent friendly expression, clear bold dark outlines, restrained flat colors, and a strong silhouette legible as a 48-pixel icon, visually related to a graphic bird mascot family. Square canvas, center mark with comfortable breathing room, fully transparent background; no lettering, no emblem, no scenery, no shadows or gradients.

## dipper

Logo-brand for an open-source Blyx programming framework. A river dipper with a chestnut crown, dark teal body and conspicuous white bib, short compact silhouette. Create one original mascot as a crisp three-quarter bird bust looking right. Distinctive species anatomy, intelligent friendly expression, clear bold dark outlines, restrained flat colors, and a strong silhouette legible as a 48-pixel icon, visually related to a graphic bird mascot family. Square canvas, center mark with comfortable breathing room, fully transparent background; no lettering, no emblem, no scenery, no shadows or gradients.

## kestrel

Logo-brand for an open-source Blyx programming framework. An American kestrel with a burnt sienna crown, blue-grey cheek, bold facial stripes and tiny hooked bill. Create one original mascot as a crisp three-quarter bird bust looking right. Distinctive species anatomy, intelligent friendly expression, clear bold dark outlines, restrained flat colors, and a strong silhouette legible as a 48-pixel icon, visually related to a graphic bird mascot family. Square canvas, center mark with comfortable breathing room, fully transparent background; no lettering, no emblem, no scenery, no shadows or gradients.

## heron

Logo-brand for an open-source Blyx programming framework. A grey heron with a long tapered gold bill, slate blue crest and a sweeping S curve of the neck. Create one original mascot as a crisp three-quarter bird bust looking right. Distinctive species anatomy, intelligent friendly expression, clear bold dark outlines, restrained flat colors, and a strong silhouette legible as a 48-pixel icon, visually related to a graphic bird mascot family. Square canvas, center mark with comfortable breathing room, fully transparent background; no lettering, no emblem, no scenery, no shadows or gradients.
