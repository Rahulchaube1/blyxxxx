Blyx package logos

65 individual framework birds: https://www.blyx-lang.space/frameworks/logos
107 library illustrations: https://www.blyx-lang.space/libraries/logos
The two collections include their design briefs. Project license texts are included.
