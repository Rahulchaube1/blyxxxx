Blyx package logos

The catalog at https://www.blyx-lang.space/packages lists each package, source and release. prompts.json contains the original ten prompts. blyxtorch.png is the original BlyxTorch blue bird logo. The license texts are included.
