Blyx package logos

This collection contains one PNG for each of the 172 packages. Browse the libraries at https://www.blyx-lang.space/libraries/logos and the frameworks at https://www.blyx-lang.space/frameworks.

The library illustrations show the Blyx penguin carrying out each library’s task. library-logo-prompts.json records their design briefs. prompts.json and framework-logo-prompts.md record the briefs for earlier framework designs. The project license texts are included.
