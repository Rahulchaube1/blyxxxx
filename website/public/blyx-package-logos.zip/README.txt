Blyx package logos

Find each package and its source at https://www.blyx-lang.space/packages.

The ten statistics, monitoring and evaluation logos adapt the official Blyx penguin to each package’s task. prompts.json includes the reference and ImageGen briefs.
The eight framework bird marks are described in framework-logo-prompts.md. blyxtorch.png is the original BlyxTorch bird. License texts are included.
