Blyx package logos

The catalog at https://www.blyx-lang.space/packages links each mark to its package and source release. The first ten package prompts are in prompts.json. The eight new bird marks were generated with ImageGen from framework-logo-prompts.md. The original BlyxTorch blue bird is blyxtorch.png. The license texts are included.
