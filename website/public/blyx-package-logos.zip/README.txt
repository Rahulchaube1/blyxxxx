Blyx package logos

Ten package marks in PNG format. See https://www.blyx-lang.space/packages for package names, sources and releases.
The prompt for each generated mark is the common base followed by its subject and accent in prompts.json.
