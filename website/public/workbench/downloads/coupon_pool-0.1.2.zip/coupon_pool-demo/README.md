# Coupon Pool

![Crested auklet](vendor/coupon_pool/assets/logo.png)

Manage a finite campaign redemption pool with replenishment and explicit suspension.

Commerce and fulfillment · framework · 0.1.2

Framework bird: Crested auklet.

## Drive the workflow

Start with `coupon_pool_start()`. For each event call `coupon_pool_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `coupon_pool_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `coupon_pool_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | launch | x>0 | open | publish_offer | x |
| open | redeem | x>0 and x<r | open | issue_codes | r-x |
| open | redeem | x=r | soldout | hide_offer | 0 |
| open | pause | always | paused | pause_offer | r |
| paused | resume | always | open | publish_offer | r |
| soldout | refill | x>0 | open | publish_offer | x |

Phase IDs in order from zero: idle, open, soldout, paused.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- launch 3 pause 0 resume 0 redeem 3 refill 2
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo coupon_pool@0.1.2
blyxc native-run coupon_pool-demo/main.blyx
```

Install with `nest add coupon_pool@0.1.2` and import `vendor::coupon_pool::coupon_pool`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
