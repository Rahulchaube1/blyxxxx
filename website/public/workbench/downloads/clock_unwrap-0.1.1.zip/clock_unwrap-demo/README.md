# Clock Unwrap

![Package logo](vendor/clock_unwrap/assets/logo.png)

Convert a wrapped time-of-day to the earliest absolute minute at or after a reference minute, using a fixed 1440-minute day.

Calendar, time and scheduling · library · 0.1.1

## Function

```blyx
pub fn clock_unwrap(reference: i64, minute: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `1430,10` | `1450` |
| `30,40` | `40` |
| `0,1440` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo clock_unwrap@0.1.1
blyxc native-run clock_unwrap-demo/main.blyx
```

Install with `nest add clock_unwrap@0.1.1` and import `vendor::clock_unwrap::clock_unwrap`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
