# Gauge Hysteresis

![European bee-eater](vendor/gauge_hysteresis/assets/logo.png)

Raise and clear a flood-gauge advisory with a lower reset band using integer level units.

Maps, environment and scientific acquisition · framework · 0.1.2

Framework bird: European bee-eater.

## Drive the workflow

Start with `gauge_hysteresis_start()`. For each event call `gauge_hysteresis_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `gauge_hysteresis_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `gauge_hysteresis_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | set | x>=2 | watching | set_rise_level | x |
| watching | level | x>=r | high | announce_high | r |
| watching | level | x<r | watching | record_normal | r |
| high | level | x+2<=r | watching | announce_clear | r |
| high | level | x+2>r | high | retain_advisory | r |

Phase IDs in order from zero: idle, watching, high.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- set 12 level 12 level 11 level 10
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo gauge_hysteresis@0.1.2
blyxc native-run gauge_hysteresis-demo/main.blyx
```

Install with `nest add gauge_hysteresis@0.1.2` and import `vendor::gauge_hysteresis::gauge_hysteresis`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
