# Residual Bias

![Package logo](vendor/residual_bias/assets/logo.png)

Measure signed mean prediction minus target for paired samples. An empty batch or mismatched lengths produces zero.

Learning, forecasting and statistics · library · 0.1.1

## Function

```blyx
pub fn residual_bias(actual: vector, predicted: vector) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[2,4],[3,7]` | `2` |
| `[5],[2]` | `-3` |
| `[],[]` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo residual_bias@0.1.1
blyxc native-run residual_bias-demo/main.blyx
```

Install with `nest add residual_bias@0.1.1` and import `vendor::residual_bias::residual_bias`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
