# Scene Stream

![Green broadbill](vendor/scene_stream/assets/logo.png)

Load a destination game scene before detaching the current scene and discard stale load callbacks.

Interactive software, games and device clients · framework · 0.1.2

Framework bird: Green broadbill.

## Drive the workflow

Start with `scene_stream_start()`. For each event call `scene_stream_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `scene_stream_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `scene_stream_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | go | x>0 | loading | load_scene | x |
| loading | go | x!=r | loading | replace_request | x |
| loading | loaded | x=r | swapping | attach_scene | r |
| swapping | active | x=r | ready | detach_previous | r |
| ready | go | x!=r | loading | load_scene | x |

Phase IDs in order from zero: idle, loading, swapping, ready.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- go 5 go 6 loaded 6 active 6
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo scene_stream@0.1.2
blyxc native-run scene_stream-demo/main.blyx
```

Install with `nest add scene_stream@0.1.2` and import `vendor::scene_stream::scene_stream`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
