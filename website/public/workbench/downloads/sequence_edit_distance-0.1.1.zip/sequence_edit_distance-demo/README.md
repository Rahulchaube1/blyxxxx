# Sequence Edit Distance

![Package logo](vendor/sequence_edit_distance/assets/logo.png)

Compute unit-cost Levenshtein distance between two token ID sequences using one dynamic programming row.

Testing, documents and accessible interfaces · library · 0.1.1

## Function

```blyx
pub fn sequence_edit_distance(left: vector, right: vector) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,2,3],[2,3,4]` | `2` |
| `[],[1,2,3]` | `3` |
| `[4,4],[4,4]` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo sequence_edit_distance@0.1.1
blyxc native-run sequence_edit_distance-demo/main.blyx
```

Install with `nest add sequence_edit_distance@0.1.1` and import `vendor::sequence_edit_distance::sequence_edit_distance`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
