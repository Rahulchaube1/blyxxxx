# Matrix Diag Sum

![Package logo](vendor/matrix_diag_sum/assets/logo.png)

Sum the principal diagonal of a rectangular row-major matrix after validating its flattened length.

Scientific and numerical methods · library · 0.1.1

## Function

```blyx
pub fn matrix_diag_sum(data: vector, rows: i64, cols: i64) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,2,3,4,5,6],2,3` | `6` |
| `[3],1,1` | `3` |
| `[],0,3` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo matrix_diag_sum@0.1.1
blyxc native-run matrix_diag_sum-demo/main.blyx
```

Install with `nest add matrix_diag_sum@0.1.1` and import `vendor::matrix_diag_sum::matrix_diag_sum`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
