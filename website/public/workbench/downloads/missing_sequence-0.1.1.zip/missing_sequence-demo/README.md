# Missing Sequence

![Package logo](vendor/missing_sequence/assets/logo.png)

Find the first missing ID starting at an expected ID in an ascending stream that may contain duplicates.

Systems, queues and reliability · library · 0.1.1

## Function

```blyx
pub fn missing_sequence(ids: vector, start: f64) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[3,3,4,6],3.0` | `5` |
| `[1,2],5.0` | `5` |
| `[],0.0` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo missing_sequence@0.1.1
blyxc native-run missing_sequence-demo/main.blyx
```

Install with `nest add missing_sequence@0.1.1` and import `vendor::missing_sequence::missing_sequence`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
