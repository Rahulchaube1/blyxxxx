# Buddy Order

![Package logo](vendor/buddy_order/assets/logo.png)

Find the least buddy allocator order that holds a request in positive equal base blocks. Order zero uses one block.

Systems, queues and reliability · library · 0.1.1

## Function

```blyx
pub fn buddy_order(bytes: i64, block: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `513,256` | `2` |
| `256,256` | `0` |
| `1,0` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo buddy_order@0.1.1
blyxc native-run buddy_order-demo/main.blyx
```

Install with `nest add buddy_order@0.1.1` and import `vendor::buddy_order::buddy_order`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
