# Pair Concordance

![Package logo](vendor/pair_concordance/assets/logo.png)

Count concordant minus discordant unordered pairs for two ranked measurements. Ties contribute zero.

Learning, forecasting and statistics · library · 0.1.1

## Function

```blyx
pub fn pair_concordance(left: vector, right: vector) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,2,3],[3,2,1]` | `-3` |
| `[1,2,2],[4,5,6]` | `2` |
| `[],[]` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo pair_concordance@0.1.1
blyxc native-run pair_concordance-demo/main.blyx
```

Install with `nest add pair_concordance@0.1.1` and import `vendor::pair_concordance::pair_concordance`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
