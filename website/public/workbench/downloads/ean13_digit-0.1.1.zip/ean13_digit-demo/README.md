# Ean13 Digit

![Package logo](vendor/ean13_digit/assets/logo.png)

Derive the EAN-13 check digit from exactly twelve decimal data digits. Invalid input returns minus one.

Data integrity, identifiers and formats · library · 0.1.1

## Function

```blyx
pub fn ean13_digit(digits: vector) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[4,0,0,6,3,8,1,3,3,3,9,3]` | `1` |
| `[0,0,0,0,0,0,0,0,0,0,0,0]` | `0` |
| `[2]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo ean13_digit@0.1.1
blyxc native-run ean13_digit-demo/main.blyx
```

Install with `nest add ean13_digit@0.1.1` and import `vendor::ean13_digit::ean13_digit`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
