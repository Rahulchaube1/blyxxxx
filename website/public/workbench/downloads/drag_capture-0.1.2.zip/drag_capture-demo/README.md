# Drag Capture

![Burrowing owl](vendor/drag_capture/assets/logo.png)

Keep pointer capture with its originating pointer during drag, cancel and drop.

Interactive software, games and device clients · framework · 0.1.2

Framework bird: Burrowing owl.

## Drive the workflow

Start with `drag_capture_start()`. For each event call `drag_capture_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `drag_capture_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `drag_capture_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | down | always | dragging | capture_pointer | x |
| dragging | move | x=r | dragging | preview_position | r |
| dragging | up | x=r | idle | commit_drop | 0 |
| dragging | cancel | x=r | idle | release_capture | 0 |

Phase IDs in order from zero: idle, dragging.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- down 2 move 2 up 2
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo drag_capture@0.1.2
blyxc native-run drag_capture-demo/main.blyx
```

Install with `nest add drag_capture@0.1.2` and import `vendor::drag_capture::drag_capture`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
