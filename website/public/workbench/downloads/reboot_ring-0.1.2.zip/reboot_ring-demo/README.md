# Reboot Ring

![Greater flamingo](vendor/reboot_ring/assets/logo.png)

Admit nodes to a rolling reboot one at a time and wait for each health check before the next node.

Reliability and delivery · framework · 0.1.2

Framework bird: Greater flamingo.

## Drive the workflow

Start with `reboot_ring_start()`. For each event call `reboot_ring_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `reboot_ring_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `reboot_ring_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | plan | x>0 | ready | set_node_count | x |
| ready | reboot | r>0 | waiting | restart_one | r |
| waiting | healthy | r>1 | ready | advance_ring | r-1 |
| waiting | healthy | r=1 | done | ring_complete | 0 |
| waiting | unhealthy | always | paused | halt_ring | r |
| paused | retry | always | waiting | probe_again | r |

Phase IDs in order from zero: idle, ready, waiting, done, paused.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- plan 2 reboot 0 healthy 0 reboot 0 unhealthy 0 retry 0 healthy 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo reboot_ring@0.1.2
blyxc native-run reboot_ring-demo/main.blyx
```

Install with `nest add reboot_ring@0.1.2` and import `vendor::reboot_ring::reboot_ring`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
