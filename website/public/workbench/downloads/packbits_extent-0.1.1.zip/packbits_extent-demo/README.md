# Packbits Extent

![Package logo](vendor/packbits_extent/assets/logo.png)

Measure decoded length of a PackBits byte stream, checking run and literal boundaries. Header 128 is a no-op.

Data integrity, identifiers and formats · library · 0.1.1

## Function

```blyx
pub fn packbits_extent(encoded: vector) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,8,9,254,7,128]` | `5` |
| `[2,1]` | `-1` |
| `[128]` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo packbits_extent@0.1.1
blyxc native-run packbits_extent-demo/main.blyx
```

Install with `nest add packbits_extent@0.1.1` and import `vendor::packbits_extent::packbits_extent`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
