# Serial Newer

![Package logo](vendor/serial_newer/assets/logo.png)

Compare unsigned 32-bit serial numbers under half-range ordering. Equal and exactly half-range pairs return false.

Systems, queues and reliability · library · 0.1.1

## Function

```blyx
pub fn serial_newer(candidate: i64, baseline: i64) -> bool
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `1,4294967295` | `true` |
| `0,2147483648` | `false` |
| `3,4` | `false` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo serial_newer@0.1.1
blyxc native-run serial_newer-demo/main.blyx
```

Install with `nest add serial_newer@0.1.1` and import `vendor::serial_newer::serial_newer`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
