# Meter Consumption

![Package logo](vendor/meter_consumption/assets/logo.png)

Compute consumption between two readings on a wrapping meter, assuming at most one wrap. Modulus is one beyond the largest reading.

Commerce, allocation and measurement · library · 0.1.1

## Function

```blyx
pub fn meter_consumption(previous: i64, current: i64, modulus: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `98,3,100` | `5` |
| `5,8,100` | `3` |
| `100,1,100` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo meter_consumption@0.1.1
blyxc native-run meter_consumption-demo/main.blyx
```

Install with `nest add meter_consumption@0.1.1` and import `vendor::meter_consumption::meter_consumption`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
