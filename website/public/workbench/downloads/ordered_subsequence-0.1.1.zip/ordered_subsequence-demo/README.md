# Ordered Subsequence

![Package logo](vendor/ordered_subsequence/assets/logo.png)

Test whether a series of required events appears in order, allowing unrelated events in between.

Sequence and table processing · library · 0.1.1

## Function

```blyx
pub fn ordered_subsequence(stream: vector, required: vector) -> bool
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,9,2],[1,2]` | `true` |
| `[2,1],[1,2]` | `false` |
| `[],[]` | `true` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo ordered_subsequence@0.1.1
blyxc native-run ordered_subsequence-demo/main.blyx
```

Install with `nest add ordered_subsequence@0.1.1` and import `vendor::ordered_subsequence::ordered_subsequence`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
