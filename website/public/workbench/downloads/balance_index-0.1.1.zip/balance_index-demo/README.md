# Balance Index

![Package logo](vendor/balance_index/assets/logo.png)

Find the first index where the sum of earlier values equals the sum of later values. Return minus one if none exists.

Sequence and table processing · library · 0.1.1

## Function

```blyx
pub fn balance_index(items: vector) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,7,3,6,5,6]` | `3` |
| `[0]` | `0` |
| `[]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo balance_index@0.1.1
blyxc native-run balance_index-demo/main.blyx
```

Install with `nest add balance_index@0.1.1` and import `vendor::balance_index::balance_index`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
