# Accessible Images

![Northern lapwing](vendor/accessible_images/assets/logo.png)

Track unresolved image alternatives and count explicitly decorative images as reviewed.

Document production and accessibility · framework · 0.1.2

Framework bird: Northern lapwing.

## Drive the workflow

Start with `accessible_images_start()`. For each event call `accessible_images_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `accessible_images_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `accessible_images_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | images | x>0 | audit | request_alt_review | x |
| audit | described | r>1 | audit | accept_description | r-1 |
| audit | decorative | r>1 | audit | mark_decorative | r-1 |
| audit | described | r=1 | ready | complete_audit | 0 |
| audit | decorative | r=1 | ready | complete_audit | 0 |
| ready | publish | always | done | release_document | 0 |

Phase IDs in order from zero: idle, audit, ready, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- images 2 decorative 0 described 0 publish 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo accessible_images@0.1.2
blyxc native-run accessible_images-demo/main.blyx
```

Install with `nest add accessible_images@0.1.2` and import `vendor::accessible_images::accessible_images`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
