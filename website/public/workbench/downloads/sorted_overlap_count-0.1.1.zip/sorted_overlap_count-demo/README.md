# Sorted Overlap Count

![Package logo](vendor/sorted_overlap_count/assets/logo.png)

Count the multiset intersection of two sorted vectors while honoring repeated keys on both sides.

Sequence and table processing · library · 0.1.1

## Function

```blyx
pub fn sorted_overlap_count(left: vector, right: vector) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,2,2,2],[2,2,4]` | `2` |
| `[],[2]` | `0` |
| `[5],[1,5]` | `1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo sorted_overlap_count@0.1.1
blyxc native-run sorted_overlap_count-demo/main.blyx
```

Install with `nest add sorted_overlap_count@0.1.1` and import `vendor::sorted_overlap_count::sorted_overlap_count`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
