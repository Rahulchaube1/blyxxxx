# Frame Reorder

![White-crested laughingthrush](vendor/frame_reorder/assets/logo.png)

Deliver frames on the expected sequence number and signal missing ranges to the decoder.

Audio, images and video · framework · 0.1.2

Framework bird: White-crested laughingthrush.

## Drive the workflow

Start with `frame_reorder_start()`. For each event call `frame_reorder_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `frame_reorder_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `frame_reorder_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | first | always | reading | set_expected | x |
| reading | frame | x=r | reading | display_frame | r+1 |
| reading | frame | x<r | reading | discard_old | r |
| reading | frame | x>r | gap | request_missing | r |
| gap | recovered | x=r | reading | display_frame | r+1 |
| gap | jump | x>r | reading | seek_keyframe | x |

Phase IDs in order from zero: idle, reading, gap.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- first 3 frame 3 frame 6 recovered 4 frame 4
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo frame_reorder@0.1.2
blyxc native-run frame_reorder-demo/main.blyx
```

Install with `nest add frame_reorder@0.1.2` and import `vendor::frame_reorder::frame_reorder`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
