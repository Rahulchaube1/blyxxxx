# Coverage Minutes

![Package logo](vendor/coverage_minutes/assets/logo.png)

Sum occupied minutes over sorted nonoverlapping activity intervals clipped to a reporting window.

Calendar, time and scheduling · library · 0.1.1

## Function

```blyx
pub fn coverage_minutes(starts: vector, ends: vector, begin: f64, end_time: f64) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,6],[4,10],2.0,8.0` | `4` |
| `[1,3],[4,5],0.0,9.0` | `-1` |
| `[],[],0.0,1.0` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo coverage_minutes@0.1.1
blyxc native-run coverage_minutes-demo/main.blyx
```

Install with `nest add coverage_minutes@0.1.1` and import `vendor::coverage_minutes::coverage_minutes`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
