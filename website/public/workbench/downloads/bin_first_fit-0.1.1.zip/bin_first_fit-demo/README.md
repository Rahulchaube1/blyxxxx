# Bin First Fit

![Package logo](vendor/bin_first_fit/assets/logo.png)

Find the first container with remaining capacity for a nonnegative item. Return minus one if no container fits.

Commerce, allocation and measurement · library · 0.1.1

## Function

```blyx
pub fn bin_first_fit(remaining: vector, item: f64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[2,9,6],5.0` | `1` |
| `[2],3.0` | `-1` |
| `[0],0.0` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo bin_first_fit@0.1.1
blyxc native-run bin_first_fit-demo/main.blyx
```

Install with `nest add bin_first_fit@0.1.1` and import `vendor::bin_first_fit::bin_first_fit`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
