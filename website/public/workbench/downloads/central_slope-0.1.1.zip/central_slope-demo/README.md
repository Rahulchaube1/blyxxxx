# Central Slope

![Package logo](vendor/central_slope/assets/logo.png)

Estimate a centered finite-difference slope at an interior sample of uniformly spaced data. Invalid positions or spacing return zero.

Scientific and numerical methods · library · 0.1.1

## Function

```blyx
pub fn central_slope(ys: vector, index: i64, spacing: f64) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[0,1,4],1,1.0` | `2` |
| `[0,3,6],1,3.0` | `1` |
| `[1],0,1.0` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo central_slope@0.1.1
blyxc native-run central_slope-demo/main.blyx
```

Install with `nest add central_slope@0.1.1` and import `vendor::central_slope::central_slope`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
