# Row Stride Align

![Package logo](vendor/row_stride_align/assets/logo.png)

Calculate padded scanline storage in bytes for a packed pixel format at a byte alignment.

Audio and image processing · library · 0.1.1

## Function

```blyx
pub fn row_stride_align(pixels: i64, bits_per_pixel: i64, alignment: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `3,24,4` | `12` |
| `1,1,4` | `4` |
| `0,8,4` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo row_stride_align@0.1.1
blyxc native-run row_stride_align-demo/main.blyx
```

Install with `nest add row_stride_align@0.1.1` and import `vendor::row_stride_align::row_stride_align`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
