# Pallet Break

![Crested barbet](vendor/pallet_break/assets/logo.png)

Pick whole cases from a pallet and direct residual loose units to repacking.

Logistics, utilities and production · framework · 0.1.2

Framework bird: Crested barbet.

## Drive the workflow

Start with `pallet_break_start()`. For each event call `pallet_break_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `pallet_break_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `pallet_break_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | unpack | x>0 | picking | count_units | x |
| picking | case | x>0 and x<=r | picking | pick_case | r-x |
| picking | remainder | x=r and r>0 | loose | repack_loose | r |
| picking | finish | r=0 | done | close_pallet | 0 |
| loose | packed | x=r | done | close_pallet | 0 |

Phase IDs in order from zero: idle, picking, loose, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- unpack 11 case 8 remainder 3 packed 3
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo pallet_break@0.1.2
blyxc native-run pallet_break-demo/main.blyx
```

Install with `nest add pallet_break@0.1.2` and import `vendor::pallet_break::pallet_break`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
