# Exchange Stock

![Shoebill](vendor/exchange_stock/assets/logo.png)

Keep a replacement item reserved until receipt of the matching returned item.

Commerce and fulfillment · framework · 0.1.2

Framework bird: Shoebill.

## Drive the workflow

Start with `exchange_stock_start()`. For each event call `exchange_stock_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `exchange_stock_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `exchange_stock_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | request | x>0 | finding | find_replacement | x |
| finding | unavailable | x=r | closed | offer_refund | r |
| finding | reserved | x=r | waiting | issue_return_label | r |
| waiting | received | x=r | shipping | release_replacement | r |
| waiting | cancel | x=r | closed | unreserve | r |
| shipping | shipped | x=r | closed | close_exchange | r |

Phase IDs in order from zero: idle, finding, closed, waiting, shipping.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- request 42 reserved 42 received 42 shipped 42
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo exchange_stock@0.1.2
blyxc native-run exchange_stock-demo/main.blyx
```

Install with `nest add exchange_stock@0.1.2` and import `vendor::exchange_stock::exchange_stock`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
