# Balanced Fold Start

![Package logo](vendor/balanced_fold_start/assets/logo.png)

Locate the start row of a balanced contiguous validation fold, giving extra rows to earlier folds. Fold count itself returns the end sentinel.

Learning, forecasting and statistics · library · 0.1.1

## Function

```blyx
pub fn balanced_fold_start(rows: i64, folds: i64, fold: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `10,3,1` | `4` |
| `10,3,3` | `10` |
| `2,3,0` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo balanced_fold_start@0.1.1
blyxc native-run balanced_fold_start-demo/main.blyx
```

Install with `nest add balanced_fold_start@0.1.1` and import `vendor::balanced_fold_start::balanced_fold_start`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
