# Stable Rank

![Package logo](vendor/stable_rank/assets/logo.png)

Return the zero-based ascending rank of one row, breaking ties by its original index. Invalid indices return minus one.

Sequence and table processing · library · 0.1.1

## Function

```blyx
pub fn stable_rank(items: vector, index: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[3,1,3],2` | `2` |
| `[3,1,3],0` | `1` |
| `[],0` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo stable_rank@0.1.1
blyxc native-run stable_rank-demo/main.blyx
```

Install with `nest add stable_rank@0.1.1` and import `vendor::stable_rank::stable_rank`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
