# Comment Appeals

![Great grey owl](vendor/comment_appeals/assets/logo.png)

Preserve a moderation case ID across hiding, appeal, review and restoration.

Publishing and collaboration · framework · 0.1.2

Framework bird: Great grey owl.

## Drive the workflow

Start with `comment_appeals_start()`. For each event call `comment_appeals_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `comment_appeals_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `comment_appeals_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | flag | x>0 | flagged | open_case | x |
| flagged | dismiss | x=r | closed | leave_visible | r |
| flagged | hide | x=r | hidden | suppress | r |
| hidden | appeal | x=r | review | request_second_review | r |
| review | uphold | x=r | closed | keep_hidden | r |
| review | reverse | x=r | closed | restore | r |

Phase IDs in order from zero: idle, flagged, closed, hidden, review.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- flag 71 hide 71 appeal 71 reverse 71
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo comment_appeals@0.1.2
blyxc native-run comment_appeals-demo/main.blyx
```

Install with `nest add comment_appeals@0.1.2` and import `vendor::comment_appeals::comment_appeals`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
