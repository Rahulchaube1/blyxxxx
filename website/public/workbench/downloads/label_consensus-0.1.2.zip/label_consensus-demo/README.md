# Label Consensus

![Andean cock-of-the-rock](vendor/label_consensus/assets/logo.png)

Require a second independent host-provided label to agree or route the sample for adjudication.

Machine learning and evaluation · framework · 0.1.2

Framework bird: Andean cock-of-the-rock.

## Drive the workflow

Start with `label_consensus_start()`. For each event call `label_consensus_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `label_consensus_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `label_consensus_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | first | always | second | request_blind_vote | x |
| second | vote | x=r | accepted | write_consensus | r |
| second | vote | x!=r | disputed | request_adjudication | r |
| disputed | rule | always | accepted | write_ruling | x |
| accepted | reopen | always | idle | erase_consensus | 0 |

Phase IDs in order from zero: idle, second, accepted, disputed.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- first 3 vote 4 rule 4 reopen 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo label_consensus@0.1.2
blyxc native-run label_consensus-demo/main.blyx
```

Install with `nest add label_consensus@0.1.2` and import `vendor::label_consensus::label_consensus`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
