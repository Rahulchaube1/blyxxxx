# Tile Pyramid

![Blue-footed booby](vendor/tile_pyramid/assets/logo.png)

Publish pyramid levels in descending zoom order and close only after zoom zero is complete.

Maps, environment and scientific acquisition · framework · 0.1.2

Framework bird: Blue-footed booby.

## Drive the workflow

Start with `tile_pyramid_start()`. For each event call `tile_pyramid_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `tile_pyramid_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `tile_pyramid_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | seed | always | building | render_level | x |
| building | level | x=r and r>0 | building | render_parent | r-1 |
| building | level | x=0 and r=0 | ready | build_tile_index | 0 |
| ready | publish | always | done | expose_tiles | 0 |

Phase IDs in order from zero: idle, building, ready, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- seed 2 level 2 level 1 level 0 publish 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo tile_pyramid@0.1.2
blyxc native-run tile_pyramid-demo/main.blyx
```

Install with `nest add tile_pyramid@0.1.2` and import `vendor::tile_pyramid::tile_pyramid`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
