# Alpha Over Gray

![Package logo](vendor/alpha_over_gray/assets/logo.png)

Composite one straight-alpha grayscale sample over an opaque background with nearest byte rounding.

Audio and image processing · library · 0.1.1

## Function

```blyx
pub fn alpha_over_gray(foreground: i64, background: i64, alpha: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `255,0,128` | `128` |
| `200,33,0` | `33` |
| `0,0,256` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo alpha_over_gray@0.1.1
blyxc native-run alpha_over_gray-demo/main.blyx
```

Install with `nest add alpha_over_gray@0.1.1` and import `vendor::alpha_over_gray::alpha_over_gray`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
