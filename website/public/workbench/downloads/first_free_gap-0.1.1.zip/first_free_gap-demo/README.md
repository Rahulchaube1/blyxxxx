# First Free Gap

![Package logo](vendor/first_free_gap/assets/logo.png)

Find the first start time that fits a duration past sorted, possibly overlapping reservations. Ignore empty reservations.

Calendar, time and scheduling · library · 0.1.1

## Function

```blyx
pub fn first_free_gap(starts: vector, ends: vector, earliest: f64, duration: f64) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[0,4],[3,8],0.0,2.0` | `8` |
| `[4],[8],1.0,3.0` | `1` |
| `[],[],5.0,2.0` | `5` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo first_free_gap@0.1.1
blyxc native-run first_free_gap-demo/main.blyx
```

Install with `nest add first_free_gap@0.1.1` and import `vendor::first_free_gap::first_free_gap`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
