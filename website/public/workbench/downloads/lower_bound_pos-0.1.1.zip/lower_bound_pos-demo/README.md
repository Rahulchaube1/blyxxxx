# Lower Bound Pos

![Package logo](vendor/lower_bound_pos/assets/logo.png)

Locate the first element greater than or equal to a key in an ascending numeric vector. Returns the length when insertion belongs at the end.

Sequence and table processing · library · 0.1.1

## Function

```blyx
pub fn lower_bound_pos(items: vector, key: f64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,2,2,8],2.0` | `1` |
| `[],4.0` | `0` |
| `[1,2],3.0` | `2` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo lower_bound_pos@0.1.1
blyxc native-run lower_bound_pos-demo/main.blyx
```

Install with `nest add lower_bound_pos@0.1.1` and import `vendor::lower_bound_pos::lower_bound_pos`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
