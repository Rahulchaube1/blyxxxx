# Fir Point

![Package logo](vendor/fir_point/assets/logo.png)

Evaluate one causal FIR output using taps in lag order and zero padding at the start of a signal.

Audio and image processing · library · 0.1.1

## Function

```blyx
pub fn fir_point(samples: vector, taps: vector, index: i64) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[2,4,6],[1,2],2` | `14` |
| `[2,4],[1,2],0` | `2` |
| `[],[1],0` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo fir_point@0.1.1
blyxc native-run fir_point-demo/main.blyx
```

Install with `nest add fir_point@0.1.1` and import `vendor::fir_point::fir_point`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
