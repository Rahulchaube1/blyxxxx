# Audio Preroll

![Greater racket-tailed drongo](vendor/audio_preroll/assets/logo.png)

Prime a playback buffer and recover from underrun without emitting premature play commands.

Audio, images and video · framework · 0.1.2

Framework bird: Greater racket-tailed drongo.

## Drive the workflow

Start with `audio_preroll_start()`. For each event call `audio_preroll_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `audio_preroll_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `audio_preroll_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | prime | x>0 | priming | request_frames | x |
| priming | fill | x>0 and x<r | priming | accept_frames | r-x |
| priming | fill | x>=r | playing | start_audio | 0 |
| playing | underrun | x>0 | priming | pause_and_refill | x |
| playing | stop | always | done | release_device | 0 |

Phase IDs in order from zero: idle, priming, playing, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- prime 8 fill 3 fill 5 underrun 2 fill 4 stop 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo audio_preroll@0.1.2
blyxc native-run audio_preroll-demo/main.blyx
```

Install with `nest add audio_preroll@0.1.2` and import `vendor::audio_preroll::audio_preroll`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
