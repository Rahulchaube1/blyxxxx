# Video Keycut

![Wilson's bird-of-paradise](vendor/video_keycut/assets/logo.png)

Snap a requested cut forward to the next eligible keyframe and preserve the resulting sample boundary.

Audio, images and video · framework · 0.1.2

Framework bird: Wilson's bird-of-paradise.

## Drive the workflow

Start with `video_keycut_start()`. For each event call `video_keycut_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `video_keycut_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `video_keycut_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | cut | always | seeking | request_keyframe | x |
| seeking | keyframe | x<r | seeking | skip_keyframe | r |
| seeking | keyframe | x>=r | cutting | split_at | x |
| cutting | confirm | x=r | done | index_clip | r |
| seeking | cancel | always | idle | clear_cut | 0 |

Phase IDs in order from zero: idle, seeking, cutting, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- cut 40 keyframe 35 keyframe 48 confirm 48
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo video_keycut@0.1.2
blyxc native-run video_keycut-demo/main.blyx
```

Install with `nest add video_keycut@0.1.2` and import `vendor::video_keycut::video_keycut`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
