# Polygon Double Area

![Package logo](vendor/polygon_double_area/assets/logo.png)

Compute the absolute doubled area of a simple planar polygon from its vertex coordinates using the shoelace sum.

Geometry, maps and layout · library · 0.1.1

## Function

```blyx
pub fn polygon_double_area(xs: vector, ys: vector) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[0,2,2,0],[0,0,3,3]` | `12` |
| `[0,0,2],[0,3,0]` | `6` |
| `[],[]` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo polygon_double_area@0.1.1
blyxc native-run polygon_double_area-demo/main.blyx
```

Install with `nest add polygon_double_area@0.1.1` and import `vendor::polygon_double_area::polygon_double_area`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
