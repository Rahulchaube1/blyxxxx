# Peak Sample Index

![Package logo](vendor/peak_sample_index/assets/logo.png)

Locate the first sample of greatest absolute magnitude, preserving the index for waveform annotation. Empty input returns minus one.

Audio and image processing · library · 0.1.1

## Function

```blyx
pub fn peak_sample_index(samples: vector) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,-4,3]` | `1` |
| `[-4,4]` | `0` |
| `[]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo peak_sample_index@0.1.1
blyxc native-run peak_sample_index-demo/main.blyx
```

Install with `nest add peak_sample_index@0.1.1` and import `vendor::peak_sample_index::peak_sample_index`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
