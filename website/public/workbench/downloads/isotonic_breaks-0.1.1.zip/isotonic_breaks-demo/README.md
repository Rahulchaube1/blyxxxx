# Isotonic Breaks

![Package logo](vendor/isotonic_breaks/assets/logo.png)

Count adjacent violations of a nondecreasing response curve before monotonic calibration.

Learning, forecasting and statistics · library · 0.1.1

## Function

```blyx
pub fn isotonic_breaks(response: vector, tolerance: f64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,0,3,2],0.0` | `2` |
| `[1,0,3,2],1.0` | `0` |
| `[],-1.0` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo isotonic_breaks@0.1.1
blyxc native-run isotonic_breaks-demo/main.blyx
```

Install with `nest add isotonic_breaks@0.1.1` and import `vendor::isotonic_breaks::isotonic_breaks`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
