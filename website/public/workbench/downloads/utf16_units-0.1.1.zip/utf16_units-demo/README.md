# Utf16 Units

![Package logo](vendor/utf16_units/assets/logo.png)

Count UTF-16 code units for an array of Unicode scalar values and reject malformed scalar values.

Testing, documents and accessible interfaces · library · 0.1.1

## Function

```blyx
pub fn utf16_units(scalars: vector) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[65,128512]` | `3` |
| `[55296]` | `-1` |
| `[]` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo utf16_units@0.1.1
blyxc native-run utf16_units-demo/main.blyx
```

Install with `nest add utf16_units@0.1.1` and import `vendor::utf16_units::utf16_units`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
