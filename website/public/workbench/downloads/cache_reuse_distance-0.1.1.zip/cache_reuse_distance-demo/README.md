# Cache Reuse Distance

![Package logo](vendor/cache_reuse_distance/assets/logo.png)

Count distinct addresses since the previous identical reference to estimate LRU stack distance. A cold reference returns minus one.

Systems, queues and reliability · library · 0.1.1

## Function

```blyx
pub fn cache_reuse_distance(trace: vector, index: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,2,2,3,1],4` | `2` |
| `[1,1],1` | `0` |
| `[9],0` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo cache_reuse_distance@0.1.1
blyxc native-run cache_reuse_distance-demo/main.blyx
```

Install with `nest add cache_reuse_distance@0.1.1` and import `vendor::cache_reuse_distance::cache_reuse_distance`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
