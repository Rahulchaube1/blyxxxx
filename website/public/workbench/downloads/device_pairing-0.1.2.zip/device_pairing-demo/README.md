# Device Pairing

![Bateleur eagle](vendor/device_pairing/assets/logo.png)

Match a nonsecret device discovery ID across discovery, user selection and connection callbacks.

Interactive software, games and device clients · framework · 0.1.2

Framework bird: Bateleur eagle.

## Drive the workflow

Start with `device_pairing_start()`. For each event call `device_pairing_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `device_pairing_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `device_pairing_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | discover | x>0 | found | display_device | x |
| found | select | x=r | connecting | request_connection | r |
| connecting | connected | x=r | paired | enable_device | r |
| connecting | timeout | always | found | offer_retry | r |
| paired | disconnect | x=r | idle | remove_device | 0 |

Phase IDs in order from zero: idle, found, connecting, paired.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- discover 7 select 7 timeout 0 select 7 connected 7
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo device_pairing@0.1.2
blyxc native-run device_pairing-demo/main.blyx
```

Install with `nest add device_pairing@0.1.2` and import `vendor::device_pairing::device_pairing`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
