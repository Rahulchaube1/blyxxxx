# Feature Freeze

![Greater sage-grouse](vendor/feature_freeze/assets/logo.png)

Bind a model fit to one feature schema and request re-encoding when a serving schema differs.

Machine learning and evaluation · framework · 0.1.2

Framework bird: Greater sage-grouse.

## Drive the workflow

Start with `feature_freeze_start()`. For each event call `feature_freeze_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `feature_freeze_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `feature_freeze_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | schema | x>0 | fitting | freeze_columns | x |
| fitting | fit | x=r | trained | persist_model | r |
| trained | serve | x=r | serving | load_model | r |
| trained | serve | x!=r | remap | request_mapping | r |
| remap | mapped | x=r | serving | load_model | r |
| serving | changed | x!=r | remap | request_mapping | r |

Phase IDs in order from zero: idle, fitting, trained, serving, remap.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- schema 7 fit 7 serve 8 mapped 7
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo feature_freeze@0.1.2
blyxc native-run feature_freeze-demo/main.blyx
```

Install with `nest add feature_freeze@0.1.2` and import `vendor::feature_freeze::feature_freeze`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
