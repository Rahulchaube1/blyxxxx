# Ring Occupancy

![Package logo](vendor/ring_occupancy/assets/logo.png)

Count occupied slots in a one-empty-slot circular queue with wrapped read and write cursors.

Systems, queues and reliability · library · 0.1.1

## Function

```blyx
pub fn ring_occupancy(read_pos: i64, write_pos: i64, size: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `6,2,8` | `4` |
| `3,3,8` | `0` |
| `0,2,2` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo ring_occupancy@0.1.1
blyxc native-run ring_occupancy-demo/main.blyx
```

Install with `nest add ring_occupancy@0.1.1` and import `vendor::ring_occupancy::ring_occupancy`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
