# Inspection Lot

![Western capercaillie](vendor/inspection_lot/assets/logo.png)

Release, reject or rework a lot based on observed defects and its configured acceptance limit.

Logistics, utilities and production · framework · 0.1.2

Framework bird: Western capercaillie.

## Drive the workflow

Start with `inspection_lot_start()`. For each event call `inspection_lot_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `inspection_lot_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `inspection_lot_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | limit | always | sampling | inspect_lot | x |
| sampling | defects | x<=r | approved | release_lot | r |
| sampling | defects | x>r | rework | segregate_lot | r |
| rework | retest | always | sampling | inspect_lot | r |
| rework | scrap | always | rejected | discard_lot | r |

Phase IDs in order from zero: idle, sampling, approved, rework, rejected.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- limit 2 defects 4 retest 0 defects 1
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo inspection_lot@0.1.2
blyxc native-run inspection_lot-demo/main.blyx
```

Install with `nest add inspection_lot@0.1.2` and import `vendor::inspection_lot::inspection_lot`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
