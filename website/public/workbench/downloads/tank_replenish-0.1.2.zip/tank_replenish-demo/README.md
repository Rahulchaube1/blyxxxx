# Tank Replenish

![Kori bustard](vendor/tank_replenish/assets/logo.png)

Request a refill below a low-water mark and close the order only after level recovery.

Logistics, utilities and production · framework · 0.1.2

Framework bird: Kori bustard.

## Drive the workflow

Start with `tank_replenish_start()`. For each event call `tank_replenish_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `tank_replenish_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `tank_replenish_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | low | x>0 | watching | set_low_mark | x |
| watching | level | x<r | ordered | place_refill | r |
| watching | level | x>=r | watching | record_level | r |
| ordered | level | x<r | ordered | await_delivery | r |
| ordered | level | x>=r | watching | close_refill | r |
| ordered | cancel | always | watching | cancel_refill | r |

Phase IDs in order from zero: idle, watching, ordered.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- low 4 level 3 level 2 level 6
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo tank_replenish@0.1.2
blyxc native-run tank_replenish-demo/main.blyx
```

Install with `nest add tank_replenish@0.1.2` and import `vendor::tank_replenish::tank_replenish`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
