# Incident Silence

![Victoria crowned pigeon](vendor/incident_silence/assets/logo.png)

Suppress repeated notifications until a quiet period expires while allowing severity escalation.

Reliability and delivery · framework · 0.1.2

Framework bird: Victoria crowned pigeon.

## Drive the workflow

Start with `incident_silence_start()`. For each event call `incident_silence_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `incident_silence_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `incident_silence_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | silence | x>0 | muted | mute_until | x |
| muted | alarm | x<r | muted | suppress_duplicate | r |
| muted | alarm | x>=r | paging | notify_oncall | x |
| muted | critical | always | paging | bypass_mute | r |
| paging | acknowledge | always | tracked | open_followup | r |
| tracked | resolve | always | closed | close_incident | 0 |

Phase IDs in order from zero: idle, muted, paging, tracked, closed.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- silence 10 alarm 8 critical 0 acknowledge 0 resolve 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo incident_silence@0.1.2
blyxc native-run incident_silence-demo/main.blyx
```

Install with `nest add incident_silence@0.1.2` and import `vendor::incident_silence::incident_silence`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
