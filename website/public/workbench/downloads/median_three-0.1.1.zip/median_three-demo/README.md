# Median Three

![Package logo](vendor/median_three/assets/logo.png)

Remove isolated impulses from a three-sample window by selecting its median, including ties.

Audio and image processing · library · 0.1.1

## Function

```blyx
pub fn median_three(first: f64, middle: f64, last: f64) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `2.0,30.0,3.0` | `3` |
| `5.0,1.0,5.0` | `5` |
| `3.0,2.0,1.0` | `2` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo median_three@0.1.1
blyxc native-run median_three-demo/main.blyx
```

Install with `nest add median_three@0.1.1` and import `vendor::median_three::median_three`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
