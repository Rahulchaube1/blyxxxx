# Gini Impurity

![Package logo](vendor/gini_impurity/assets/logo.png)

Compute class impurity from nonnegative class counts. An empty or zero-mass histogram yields zero.

Learning, forecasting and statistics · library · 0.1.1

## Function

```blyx
pub fn gini_impurity(counts: vector) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[2,2]` | `0.5` |
| `[3,0]` | `0` |
| `[-1]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo gini_impurity@0.1.1
blyxc native-run gini_impurity-demo/main.blyx
```

Install with `nest add gini_impurity@0.1.1` and import `vendor::gini_impurity::gini_impurity`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
