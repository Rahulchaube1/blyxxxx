# Session Count

![Package logo](vendor/session_count/assets/logo.png)

Count activity sessions in a sorted event timeline. A gap strictly greater than the timeout starts a new session.

Calendar, time and scheduling · library · 0.1.1

## Function

```blyx
pub fn session_count(times: vector, timeout: f64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,4,8,20],4.0` | `2` |
| `[1,5],4.0` | `1` |
| `[3,1],2.0` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo session_count@0.1.1
blyxc native-run session_count-demo/main.blyx
```

Install with `nest add session_count@0.1.1` and import `vendor::session_count::session_count`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
