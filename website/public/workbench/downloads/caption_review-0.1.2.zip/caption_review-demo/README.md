# Caption Review

![Grey crowned crane](vendor/caption_review/assets/logo.png)

Track outstanding subtitle corrections and return a corrected track for listening approval.

Publishing and collaboration · framework · 0.1.2

Framework bird: Grey crowned crane.

## Drive the workflow

Start with `caption_review_start()`. For each event call `caption_review_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `caption_review_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `caption_review_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | report | x>0 | fixing | queue_fixes | x |
| fixing | correct | x>0 and x<r | fixing | record_fixes | r-x |
| fixing | correct | x=r | listen | request_listen | 0 |
| listen | report | x>0 | fixing | queue_fixes | x |
| listen | approve | always | done | deliver_track | 0 |

Phase IDs in order from zero: idle, fixing, listen, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- report 5 correct 2 correct 3 report 1 correct 1 approve 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo caption_review@0.1.2
blyxc native-run caption_review-demo/main.blyx
```

Install with `nest add caption_review@0.1.2` and import `vendor::caption_review::caption_review`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
