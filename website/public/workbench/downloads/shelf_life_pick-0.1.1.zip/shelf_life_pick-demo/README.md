# Shelf Life Pick

![Package logo](vendor/shelf_life_pick/assets/logo.png)

Choose the earliest nonexpired lot with sufficient stock for an unsplit order. Ties preserve input order.

Commerce, allocation and measurement · library · 0.1.1

## Function

```blyx
pub fn shelf_life_pick(expires: vector, stock: vector, day: f64, need: f64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[8,7,9],[2,5,6],7.0,4.0` | `1` |
| `[2],[8],3.0,1.0` | `-1` |
| `[5,5],[1,1],5.0,1.0` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo shelf_life_pick@0.1.1
blyxc native-run shelf_life_pick-demo/main.blyx
```

Install with `nest add shelf_life_pick@0.1.1` and import `vendor::shelf_life_pick::shelf_life_pick`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
