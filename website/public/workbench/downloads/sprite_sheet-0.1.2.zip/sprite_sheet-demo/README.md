# Sprite Sheet

![Gouldian finch](vendor/sprite_sheet/assets/logo.png)

Assign frames into a fixed-capacity sprite atlas and reject an incomplete finalization.

Audio, images and video · framework · 0.1.2

Framework bird: Gouldian finch.

## Drive the workflow

Start with `sprite_sheet_start()`. For each event call `sprite_sheet_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `sprite_sheet_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `sprite_sheet_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | allocate | x>0 | packing | reserve_cells | x |
| packing | frame | x>0 and x<=r | packing | occupy_cells | r-x |
| packing | seal | r=0 | ready | emit_atlas | 0 |
| ready | mipmaps | always | done | write_texture | 0 |
| packing | abandon | always | idle | release_cells | 0 |

Phase IDs in order from zero: idle, packing, ready, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- allocate 3 frame 2 frame 1 seal 0 mipmaps 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo sprite_sheet@0.1.2
blyxc native-run sprite_sheet-demo/main.blyx
```

Install with `nest add sprite_sheet@0.1.2` and import `vendor::sprite_sheet::sprite_sheet`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
