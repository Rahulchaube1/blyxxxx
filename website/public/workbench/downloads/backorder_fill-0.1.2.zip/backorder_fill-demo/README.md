# Backorder Fill

![Southern cassowary](vendor/backorder_fill/assets/logo.png)

Release a backordered line only after cumulative inbound receipts satisfy its shortage.

Commerce and fulfillment · framework · 0.1.2

Framework bird: Southern cassowary.

## Drive the workflow

Start with `backorder_fill_start()`. For each event call `backorder_fill_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `backorder_fill_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `backorder_fill_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | shortage | x>0 | waiting | notify_wait | x |
| waiting | receive | x>0 and x<r | waiting | reduce_shortage | r-x |
| waiting | receive | x>=r | ready | allocate_line | 0 |
| ready | ship | always | closed | dispatch | 0 |
| waiting | cancel | always | closed | cancel_line | r |

Phase IDs in order from zero: idle, waiting, ready, closed.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- shortage 9 receive 3 receive 8 ship 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo backorder_fill@0.1.2
blyxc native-run backorder_fill-demo/main.blyx
```

Install with `nest add backorder_fill@0.1.2` and import `vendor::backorder_fill::backorder_fill`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
