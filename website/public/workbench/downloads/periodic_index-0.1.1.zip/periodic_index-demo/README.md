# Periodic Index

![Package logo](vendor/periodic_index/assets/logo.png)

Wrap a signed pixel or lattice coordinate into a repeating axis of positive integer width.

Geometry, maps and layout · library · 0.1.1

## Function

```blyx
pub fn periodic_index(position: i64, width: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `-1,8` | `7` |
| `17,8` | `1` |
| `5,0` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo periodic_index@0.1.1
blyxc native-run periodic_index-demo/main.blyx
```

Install with `nest add periodic_index@0.1.1` and import `vendor::periodic_index::periodic_index`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
