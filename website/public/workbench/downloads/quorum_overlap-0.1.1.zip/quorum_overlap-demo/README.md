# Quorum Overlap

![Package logo](vendor/quorum_overlap/assets/logo.png)

Calculate the minimum overlap between two successful quorum sets in a universe of distinct nodes.

Systems, queues and reliability · library · 0.1.1

## Function

```blyx
pub fn quorum_overlap(nodes: i64, readers: i64, writers: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `5,3,3` | `1` |
| `5,2,2` | `0` |
| `5,6,1` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo quorum_overlap@0.1.1
blyxc native-run quorum_overlap-demo/main.blyx
```

Install with `nest add quorum_overlap@0.1.1` and import `vendor::quorum_overlap::quorum_overlap`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
