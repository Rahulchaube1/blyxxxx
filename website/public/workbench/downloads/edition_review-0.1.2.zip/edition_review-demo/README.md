# Edition Review

![King eider drake](vendor/edition_review/assets/logo.png)

Keep editorial approval tied to the submitted revision even when an author edits during review.

Publishing and collaboration · framework · 0.1.2

Framework bird: King eider drake.

## Drive the workflow

Start with `edition_review_start()`. For each event call `edition_review_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `edition_review_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `edition_review_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | submit | x>0 | review | request_review | x |
| review | revise | x>r | review | replace_draft | x |
| review | approve | x=r | approved | queue_publication | r |
| approved | publish | x=r | live | announce | r |
| review | reject | x=r | idle | return_draft | 0 |

Phase IDs in order from zero: idle, review, approved, live.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- submit 3 revise 4 approve 4 publish 4
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo edition_review@0.1.2
blyxc native-run edition_review-demo/main.blyx
```

Install with `nest add edition_review@0.1.2` and import `vendor::edition_review::edition_review`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
