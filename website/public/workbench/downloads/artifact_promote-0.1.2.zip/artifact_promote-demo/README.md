# Artifact Promote

![Red-legged seriema](vendor/artifact_promote/assets/logo.png)

Promote exactly the artifact digest token that passed staging and block substituted build IDs.

Reliability and delivery · framework · 0.1.2

Framework bird: Red-legged seriema.

## Drive the workflow

Start with `artifact_promote_start()`. For each event call `artifact_promote_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `artifact_promote_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `artifact_promote_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | build | x>0 | staged | deploy_staging | x |
| staged | failed | x=r | rejected | quarantine | r |
| staged | passed | x=r | signed | request_signoff | r |
| signed | approve | x=r | ready | permit_promotion | r |
| ready | promote | x=r | live | deploy_production | r |

Phase IDs in order from zero: idle, staged, rejected, signed, ready, live.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- build 17 passed 17 approve 17 promote 17
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo artifact_promote@0.1.2
blyxc native-run artifact_promote-demo/main.blyx
```

Install with `nest add artifact_promote@0.1.2` and import `vendor::artifact_promote::artifact_promote`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
