# Undo Cursor

![Black swan](vendor/undo_cursor/assets/logo.png)

Bound undo traversal by the number of applied edits and clear history at a committed savepoint.

Interactive software, games and device clients · framework · 0.1.2

Framework bird: Black swan.

## Drive the workflow

Start with `undo_cursor_start()`. For each event call `undo_cursor_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `undo_cursor_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `undo_cursor_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | open | always | editing | load_history | x |
| editing | apply | always | editing | push_edit | r+1 |
| editing | undo | r>0 | editing | pop_edit | r-1 |
| editing | save | always | editing | reset_history | 0 |
| editing | close | r=0 | done | close_clean | 0 |

Phase IDs in order from zero: idle, editing, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- open 0 apply 0 apply 0 undo 0 save 0 close 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo undo_cursor@0.1.2
blyxc native-run undo_cursor-demo/main.blyx
```

Install with `nest add undo_cursor@0.1.2` and import `vendor::undo_cursor::undo_cursor`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
