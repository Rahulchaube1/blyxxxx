# Take Punch

![Sword-billed hummingbird](vendor/take_punch/assets/logo.png)

Punch a recording in and out on a monotonic sample clock and retain the captured duration.

Audio, images and video · framework · 0.1.2

Framework bird: Sword-billed hummingbird.

## Drive the workflow

Start with `take_punch_start()`. For each event call `take_punch_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `take_punch_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `take_punch_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | cue | always | cued | remember_marker | x |
| cued | punch | x>=r | recording | start_capture | x |
| recording | out | x>r | captured | stop_capture | x-r |
| captured | discard | always | idle | drop_take | 0 |
| captured | keep | always | saved | catalog_take | r |

Phase IDs in order from zero: idle, cued, recording, captured, saved.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- cue 90 punch 100 out 130 keep 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo take_punch@0.1.2
blyxc native-run take_punch-demo/main.blyx
```

Install with `nest add take_punch@0.1.2` and import `vendor::take_punch::take_punch`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
