# Edit Lease

![Secretarybird](vendor/edit_lease/assets/logo.png)

Control an exclusive editing window with renewal, expiry and explicit release using logical timestamps.

Publishing and collaboration · framework · 0.1.2

Framework bird: Secretarybird.

## Drive the workflow

Start with `edit_lease_start()`. For each event call `edit_lease_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `edit_lease_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `edit_lease_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | acquire | x>0 | leased | grant_until | x |
| leased | renew | x>r | leased | extend_until | x |
| leased | clock | x>=r | idle | expire | 0 |
| leased | release | always | idle | unlock | 0 |

Phase IDs in order from zero: idle, leased.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- acquire 10 renew 20 clock 20
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo edit_lease@0.1.2
blyxc native-run edit_lease-demo/main.blyx
```

Install with `nest add edit_lease@0.1.2` and import `vendor::edit_lease::edit_lease`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
