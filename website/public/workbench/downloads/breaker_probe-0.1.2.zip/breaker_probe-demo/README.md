# Breaker Probe

![Black-necked stilt](vendor/breaker_probe/assets/logo.png)

Open a circuit after a configured number of consecutive failures and admit a single recovery probe.

Reliability and delivery · framework · 0.1.2

Framework bird: Black-necked stilt.

## Drive the workflow

Start with `breaker_probe_start()`. For each event call `breaker_probe_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `breaker_probe_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `breaker_probe_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | arm | x>0 | armed | record_limit | x |
| armed | failure | r>1 | armed | consume_attempt | r-1 |
| armed | failure | r=1 | open | trip | 0 |
| armed | success | x>0 | armed | reset_budget | x |
| open | probe | always | testing | admit_one | 0 |
| testing | failure | always | open | reopen | 0 |
| testing | success | x>0 | armed | close_breaker | x |

Phase IDs in order from zero: idle, armed, open, testing.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- arm 2 failure 0 failure 0 probe 0 success 2
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo breaker_probe@0.1.2
blyxc native-run breaker_probe-demo/main.blyx
```

Install with `nest add breaker_probe@0.1.2` and import `vendor::breaker_probe::breaker_probe`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
