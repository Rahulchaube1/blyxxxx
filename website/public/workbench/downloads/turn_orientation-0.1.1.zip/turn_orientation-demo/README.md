# Turn Orientation

![Package logo](vendor/turn_orientation/assets/logo.png)

Determine the direction of a planar turn from six coordinates. Returns one for counterclockwise, zero for collinear, minus one for clockwise.

Geometry, maps and layout · library · 0.1.1

## Function

```blyx
pub fn turn_orientation(ax: f64, ay: f64, bx: f64, by: f64, cx: f64, cy: f64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `0.0,0.0,1.0,0.0,0.0,1.0` | `1` |
| `0.0,0.0,0.0,1.0,1.0,0.0` | `-1` |
| `0.0,0.0,1.0,1.0,2.0,2.0` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo turn_orientation@0.1.1
blyxc native-run turn_orientation-demo/main.blyx
```

Install with `nest add turn_orientation@0.1.1` and import `vendor::turn_orientation::turn_orientation`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
