# Base64 Size

![Package logo](vendor/base64_size/assets/logo.png)

Calculate the number of padded Base64 characters required for a known payload byte count.

Data integrity, identifiers and formats · library · 0.1.1

## Function

```blyx
pub fn base64_size(bytes: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `4` | `8` |
| `3` | `4` |
| `0` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo base64_size@0.1.1
blyxc native-run base64_size-demo/main.blyx
```

Install with `nest add base64_size@0.1.1` and import `vendor::base64_size::base64_size`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
