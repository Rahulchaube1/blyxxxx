# Cart Reserve

![Scarlet macaw](vendor/cart_reserve/assets/logo.png)

Reserve a fixed cart quantity, release unneeded units and commit the exact remainder.

Commerce and fulfillment · framework · 0.1.2

Framework bird: Scarlet macaw.

## Drive the workflow

Start with `cart_reserve_start()`. For each event call `cart_reserve_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `cart_reserve_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `cart_reserve_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | reserve | x>0 | held | hold_stock | x |
| held | release | x>0 and x<r | held | release_units | r-x |
| held | release | x=r | idle | release_all | 0 |
| held | checkout | x=r | sold | commit_units | r |

Phase IDs in order from zero: idle, held, sold.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- reserve 8 release 3 checkout 5
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo cart_reserve@0.1.2
blyxc native-run cart_reserve-demo/main.blyx
```

Install with `nest add cart_reserve@0.1.2` and import `vendor::cart_reserve::cart_reserve`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
