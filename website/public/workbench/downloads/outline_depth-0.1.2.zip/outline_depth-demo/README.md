# Outline Depth

![Crested caracara](vendor/outline_depth/assets/logo.png)

Enforce one-level heading descent while allowing returns to outer levels when constructing an outline.

Document production and accessibility · framework · 0.1.2

Framework bird: Crested caracara.

## Drive the workflow

Start with `outline_depth_start()`. For each event call `outline_depth_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `outline_depth_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `outline_depth_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | heading | x=1 | open | append_heading | x |
| open | heading | x>0 and x<=r+1 | open | append_heading | x |
| open | heading | x>r+1 | open | report_skipped_level | r |
| open | finish | always | done | export_outline | r |

Phase IDs in order from zero: idle, open, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- heading 1 heading 3 heading 2 heading 1 finish 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo outline_depth@0.1.2
blyxc native-run outline_depth-demo/main.blyx
```

Install with `nest add outline_depth@0.1.2` and import `vendor::outline_depth::outline_depth`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
