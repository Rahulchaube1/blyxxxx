# Microbatch Seal

![Cockatiel](vendor/microbatch_seal/assets/logo.png)

Close a microbatch on its target row count or an early flush and release only after sink confirmation.

Data systems and queues · framework · 0.1.2

Framework bird: Cockatiel.

## Drive the workflow

Start with `microbatch_seal_start()`. For each event call `microbatch_seal_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `microbatch_seal_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `microbatch_seal_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | start | x>0 | filling | set_capacity | x |
| filling | append | x>0 and x<r | filling | stage_rows | r-x |
| filling | append | x=r | sealed | write_batch | 0 |
| filling | flush | always | sealed | write_partial | r |
| sealed | ack | always | done | commit_batch | r |
| sealed | fail | always | sealed | rewrite_batch | r |

Phase IDs in order from zero: idle, filling, sealed, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- start 8 append 3 flush 0 fail 0 ack 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo microbatch_seal@0.1.2
blyxc native-run microbatch_seal-demo/main.blyx
```

Install with `nest add microbatch_seal@0.1.2` and import `vendor::microbatch_seal::microbatch_seal`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
