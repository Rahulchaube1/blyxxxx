# Striped Owner

![Package logo](vendor/striped_owner/assets/logo.png)

Map a logical block address to a disk in a round-robin stripe layout with configurable blocks per stripe.

Systems, queues and reliability · library · 0.1.1

## Function

```blyx
pub fn striped_owner(block: i64, stripe: i64, disks: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `11,2,3` | `2` |
| `12,2,3` | `0` |
| `2,0,3` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo striped_owner@0.1.1
blyxc native-run striped_owner-demo/main.blyx
```

Install with `nest add striped_owner@0.1.1` and import `vendor::striped_owner::striped_owner`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
