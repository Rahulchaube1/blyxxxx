# Subscription Grace

![Demoiselle crane](vendor/subscription_grace/assets/logo.png)

Control renewal, grace-period expiration and reactivation by comparing absolute billing deadlines.

Commerce and fulfillment · framework · 0.1.2

Framework bird: Demoiselle crane.

## Drive the workflow

Start with `subscription_grace_start()`. For each event call `subscription_grace_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `subscription_grace_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `subscription_grace_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | start | x>0 | active | open_term | x |
| active | renew | x>r | active | extend_term | x |
| active | unpaid | x>=r | grace | begin_grace | x |
| grace | extend | x>r | grace | set_grace_end | x |
| grace | clock | x>=r | suspended | pause_service | r |
| suspended | renew | x>r | active | restore_service | x |
| grace | renew | x>r | active | restore_service | x |

Phase IDs in order from zero: idle, active, grace, suspended.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- start 30 unpaid 30 extend 37 clock 37 renew 65
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo subscription_grace@0.1.2
blyxc native-run subscription_grace-demo/main.blyx
```

Install with `nest add subscription_grace@0.1.2` and import `vendor::subscription_grace::subscription_grace`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
