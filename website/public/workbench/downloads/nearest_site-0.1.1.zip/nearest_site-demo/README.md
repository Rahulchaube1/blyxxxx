# Nearest Site

![Package logo](vendor/nearest_site/assets/logo.png)

Find the first closest planar site by squared Euclidean distance. Return minus one for empty or mismatched coordinate arrays.

Geometry, maps and layout · library · 0.1.1

## Function

```blyx
pub fn nearest_site(xs: vector, ys: vector, x: f64, y: f64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[0,2,9],[0,0,0],3.0,0.0` | `1` |
| `[0,2],[0,0],1.0,0.0` | `0` |
| `[],[],4.0,2.0` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo nearest_site@0.1.1
blyxc native-run nearest_site-demo/main.blyx
```

Install with `nest add nearest_site@0.1.1` and import `vendor::nearest_site::nearest_site`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
