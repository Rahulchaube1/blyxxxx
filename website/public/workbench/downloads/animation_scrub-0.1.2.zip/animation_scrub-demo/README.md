# Animation Scrub

![Rainbow lorikeet](vendor/animation_scrub/assets/logo.png)

Fence asynchronous preview callbacks to the most recently selected animation frame.

Interactive software, games and device clients · framework · 0.1.2

Framework bird: Rainbow lorikeet.

## Drive the workflow

Start with `animation_scrub_start()`. For each event call `animation_scrub_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `animation_scrub_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `animation_scrub_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | seek | always | fetching | request_frame | x |
| fetching | seek | x!=r | fetching | supersede_frame | x |
| fetching | loaded | x=r | showing | draw_frame | r |
| showing | seek | x!=r | fetching | request_frame | x |
| showing | play | always | playing | resume_timeline | r |
| playing | pause | always | showing | freeze_frame | x |

Phase IDs in order from zero: idle, fetching, showing, playing.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- seek 4 seek 7 loaded 7 play 0 pause 9
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo animation_scrub@0.1.2
blyxc native-run animation_scrub-demo/main.blyx
```

Install with `nest add animation_scrub@0.1.2` and import `vendor::animation_scrub::animation_scrub`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
