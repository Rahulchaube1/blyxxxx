# Mirror Repair

![Hoatzin](vendor/mirror_repair/assets/logo.png)

Schedule missing mirror blocks and disclose availability only after a consistency probe.

Reliability and delivery · framework · 0.1.2

Framework bird: Hoatzin.

## Drive the workflow

Start with `mirror_repair_start()`. For each event call `mirror_repair_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `mirror_repair_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `mirror_repair_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | missing | x>0 | repairing | enqueue_blocks | x |
| repairing | copied | x>0 and x<r | repairing | reduce_backlog | r-x |
| repairing | copied | x=r | probing | verify_mirror | 0 |
| probing | corrupt | x>0 | repairing | enqueue_blocks | x |
| probing | clean | always | online | enable_reads | 0 |

Phase IDs in order from zero: idle, repairing, probing, online.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- missing 3 copied 3 corrupt 1 copied 1 clean 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo mirror_repair@0.1.2
blyxc native-run mirror_repair-demo/main.blyx
```

Install with `nest add mirror_repair@0.1.2` and import `vendor::mirror_repair::mirror_repair`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
