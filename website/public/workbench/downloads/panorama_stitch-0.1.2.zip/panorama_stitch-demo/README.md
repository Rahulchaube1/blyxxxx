# Panorama Stitch

![Kakapo](vendor/panorama_stitch/assets/logo.png)

Track overlapping frame pairs and require a solved alignment before blending.

Audio, images and video · framework · 0.1.2

Framework bird: Kakapo.

## Drive the workflow

Start with `panorama_stitch_start()`. For each event call `panorama_stitch_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `panorama_stitch_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `panorama_stitch_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | pairs | x>0 | matching | match_pairs | x |
| matching | pair | x>0 and x<=r | matching | mark_matched | r-x |
| matching | solve | r=0 | solving | fit_transform | 0 |
| solving | outliers | x>0 | matching | rematch_pairs | x |
| solving | aligned | always | blending | blend_tiles | 0 |
| blending | finish | always | done | publish_panorama | 0 |

Phase IDs in order from zero: idle, matching, solving, blending, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- pairs 2 pair 2 solve 0 aligned 0 finish 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo panorama_stitch@0.1.2
blyxc native-run panorama_stitch-demo/main.blyx
```

Install with `nest add panorama_stitch@0.1.2` and import `vendor::panorama_stitch::panorama_stitch`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
