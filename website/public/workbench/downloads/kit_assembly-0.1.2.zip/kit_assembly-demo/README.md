# Kit Assembly

![Brown pelican](vendor/kit_assembly/assets/logo.png)

Prevent packaging an incomplete kit and permit discovery of additional required components.

Logistics, utilities and production · framework · 0.1.2

Framework bird: Brown pelican.

## Drive the workflow

Start with `kit_assembly_start()`. For each event call `kit_assembly_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `kit_assembly_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `kit_assembly_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | parts | x>0 | assembly | stage_components | x |
| assembly | fitted | x>0 and x<=r | assembly | attach_components | r-x |
| assembly | missing | x>0 | assembly | expand_parts_list | r+x |
| assembly | pack | r=0 | sealed | pack_kit | 0 |
| sealed | label | always | done | print_label | 0 |

Phase IDs in order from zero: idle, assembly, sealed, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- parts 2 fitted 2 missing 1 fitted 1 pack 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo kit_assembly@0.1.2
blyxc native-run kit_assembly-demo/main.blyx
```

Install with `nest add kit_assembly@0.1.2` and import `vendor::kit_assembly::kit_assembly`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
