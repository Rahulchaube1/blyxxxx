# Translation Memory

![Temminck's tragopan male](vendor/translation_memory/assets/logo.png)

Associate one segment revision with a translation candidate and reject stale approval after source edits.

Document production and accessibility · framework · 0.1.2

Framework bird: Temminck's tragopan male.

## Drive the workflow

Start with `translation_memory_start()`. For each event call `translation_memory_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `translation_memory_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `translation_memory_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | source | x>0 | lookup | find_match | x |
| lookup | hit | x=r | review | present_match | r |
| lookup | miss | always | drafting | request_translation | r |
| drafting | ready | x=r | review | present_draft | r |
| review | edit | x>r | lookup | invalidate_candidate | x |
| review | accept | x=r | done | store_translation | r |

Phase IDs in order from zero: idle, lookup, review, drafting, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- source 4 hit 4 edit 5 miss 0 ready 5 accept 5
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo translation_memory@0.1.2
blyxc native-run translation_memory-demo/main.blyx
```

Install with `nest add translation_memory@0.1.2` and import `vendor::translation_memory::translation_memory`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
