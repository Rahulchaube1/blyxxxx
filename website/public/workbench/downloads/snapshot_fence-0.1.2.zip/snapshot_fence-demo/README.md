# Snapshot Fence

![Inca tern](vendor/snapshot_fence/assets/logo.png)

Buffer changes during snapshot export and release the change feed only at a matching snapshot fence.

Data systems and queues · framework · 0.1.2

Framework bird: Inca tern.

## Drive the workflow

Start with `snapshot_fence_start()`. For each event call `snapshot_fence_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `snapshot_fence_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `snapshot_fence_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | capture | x>0 | snapshot | record_fence | x |
| snapshot | change | x>r | snapshot | buffer_change | r |
| snapshot | change | x<=r | snapshot | covered_by_snapshot | r |
| snapshot | sealed | x=r | catchup | drain_buffer | r |
| catchup | applied | x>=r | live | resume_tail | x |
| live | applied | x>r | live | advance_offset | x |

Phase IDs in order from zero: idle, snapshot, catchup, live.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- capture 20 change 19 change 21 sealed 20 applied 21
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo snapshot_fence@0.1.2
blyxc native-run snapshot_fence-demo/main.blyx
```

Install with `nest add snapshot_fence@0.1.2` and import `vendor::snapshot_fence::snapshot_fence`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
