# Dot Kahan

![Package logo](vendor/dot_kahan/assets/logo.png)

Accumulate a dot product with compensated summation for bounded finite inputs. Mismatched arrays return zero.

Scientific and numerical methods · library · 0.1.1

## Function

```blyx
pub fn dot_kahan(left: vector, right: vector) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,2,3],[4,5,6]` | `32` |
| `[],[]` | `0` |
| `[1],[]` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo dot_kahan@0.1.1
blyxc native-run dot_kahan-demo/main.blyx
```

Install with `nest add dot_kahan@0.1.1` and import `vendor::dot_kahan::dot_kahan`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
