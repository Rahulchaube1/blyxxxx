# Zero Cross Count

![Package logo](vendor/zero_cross_count/assets/logo.png)

Count sign changes in sampled audio, ignoring zero-valued plateaus.

Audio and image processing · library · 0.1.1

## Function

```blyx
pub fn zero_cross_count(samples: vector) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[-1,0,1,0,-1]` | `2` |
| `[0,0]` | `0` |
| `[2,0,3]` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo zero_cross_count@0.1.1
blyxc native-run zero_cross_count-demo/main.blyx
```

Install with `nest add zero_cross_count@0.1.1` and import `vendor::zero_cross_count::zero_cross_count`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
