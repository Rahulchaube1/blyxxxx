# Annotation Budget

![Amazonian umbrellabird male](vendor/annotation_budget/assets/logo.png)

Reserve a bounded labeling budget, route affordable tasks and close the campaign when funds run out.

Machine learning and evaluation · framework · 0.1.2

Framework bird: Amazonian umbrellabird male.

## Drive the workflow

Start with `annotation_budget_start()`. For each event call `annotation_budget_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `annotation_budget_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `annotation_budget_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | fund | x>0 | active | set_budget | x |
| active | quote | x>r | active | defer_task | r |
| active | quote | x>0 and x<r | active | assign_task | r-x |
| active | quote | x=r | exhausted | assign_last | 0 |
| exhausted | extend | x>0 | active | set_budget | x |
| active | close | always | done | return_unused | r |

Phase IDs in order from zero: idle, active, exhausted, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- fund 10 quote 12 quote 4 quote 6 extend 3 close 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo annotation_budget@0.1.2
blyxc native-run annotation_budget-demo/main.blyx
```

Install with `nest add annotation_budget@0.1.2` and import `vendor::annotation_budget::annotation_budget`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
