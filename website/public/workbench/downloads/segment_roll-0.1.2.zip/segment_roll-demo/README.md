# Segment Roll

![Bearded reedling male](vendor/segment_roll/assets/logo.png)

Roll bounded log segments without losing the append that triggered rotation.

Data systems and queues · framework · 0.1.2

Framework bird: Bearded reedling male.

## Drive the workflow

Start with `segment_roll_start()`. For each event call `segment_roll_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `segment_roll_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `segment_roll_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | open | x>0 | writable | reserve_bytes | x |
| writable | append | x>0 and x<=r | writable | persist_record | r-x |
| writable | append | x>r | rotating | roll_for_record | x |
| rotating | capacity | x>=r | writable | persist_pending | x-r |
| writable | close | always | closed | sync_and_close | r |

Phase IDs in order from zero: idle, writable, rotating, closed.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- open 10 append 6 append 7 capacity 10 close 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo segment_roll@0.1.2
blyxc native-run segment_roll-demo/main.blyx
```

Install with `nest add segment_roll@0.1.2` and import `vendor::segment_roll::segment_roll`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
