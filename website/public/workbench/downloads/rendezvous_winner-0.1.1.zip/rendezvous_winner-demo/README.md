# Rendezvous Winner

![Package logo](vendor/rendezvous_winner/assets/logo.png)

Choose an available replica from precomputed rendezvous hash scores, resolving ties by lowest index. Positive flags indicate available replicas.

Systems, queues and reliability · library · 0.1.1

## Function

```blyx
pub fn rendezvous_winner(scores: vector, available: vector) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[9,8,2],[0,1,1]` | `1` |
| `[3,3],[1,1]` | `0` |
| `[],[]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo rendezvous_winner@0.1.1
blyxc native-run rendezvous_winner-demo/main.blyx
```

Install with `nest add rendezvous_winner@0.1.1` and import `vendor::rendezvous_winner::rendezvous_winner`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
