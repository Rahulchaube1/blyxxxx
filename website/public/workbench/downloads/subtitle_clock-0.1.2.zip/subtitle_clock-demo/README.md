# Subtitle Clock

![Great horned owl](vendor/subtitle_clock/assets/logo.png)

Accept nonoverlapping cues in timestamp order and mark the last closed cue for export.

Audio, images and video · framework · 0.1.2

Framework bird: Great horned owl.

## Drive the workflow

Start with `subtitle_clock_start()`. For each event call `subtitle_clock_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `subtitle_clock_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `subtitle_clock_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | begin | always | cue | write_start | x |
| cue | end | x>r | gap | write_end | x |
| gap | begin | x>=r | cue | write_start | x |
| gap | export | always | done | seal_track | r |
| cue | discard | always | gap | discard_cue | r |

Phase IDs in order from zero: idle, cue, gap, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- begin 10 end 15 begin 15 end 19 export 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo subtitle_clock@0.1.2
blyxc native-run subtitle_clock-demo/main.blyx
```

Install with `nest add subtitle_clock@0.1.2` and import `vendor::subtitle_clock::subtitle_clock`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
