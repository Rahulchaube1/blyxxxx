# Auction Close

![Australian pelican](vendor/auction_close/assets/logo.png)

Drive a single-item ascending auction with a reserve, strictly increasing bids and a settlement handoff.

Commerce and fulfillment · framework · 0.1.2

Framework bird: Australian pelican.

## Drive the workflow

Start with `auction_close_start()`. For each event call `auction_close_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `auction_close_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `auction_close_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | open | always | bidding | set_reserve | x |
| bidding | bid | x>=r | leading | accept_bid | x |
| leading | bid | x>r | leading | replace_high_bid | x |
| bidding | close | always | closed | unsold | 0 |
| leading | close | always | settling | invoice_winner | r |
| settling | paid | x=r | closed | release_item | r |

Phase IDs in order from zero: idle, bidding, leading, closed, settling.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- open 20 bid 20 bid 23 close 0 paid 23
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo auction_close@0.1.2
blyxc native-run auction_close-demo/main.blyx
```

Install with `nest add auction_close@0.1.2` and import `vendor::auction_close::auction_close`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
