# Level Checkpoint

![Horned screamer](vendor/level_checkpoint/assets/logo.png)

Track forward game progress while allowing respawns only at a previously committed checkpoint.

Interactive software, games and device clients · framework · 0.1.2

Framework bird: Horned screamer.

## Drive the workflow

Start with `level_checkpoint_start()`. For each event call `level_checkpoint_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `level_checkpoint_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `level_checkpoint_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | spawn | always | playing | set_checkpoint | x |
| playing | checkpoint | x>r | playing | save_checkpoint | x |
| playing | death | always | respawn | reload_checkpoint | r |
| respawn | loaded | x=r | playing | resume_player | r |
| playing | victory | x>=r | done | finish_level | x |

Phase IDs in order from zero: idle, playing, respawn, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- spawn 0 checkpoint 5 death 0 loaded 5 victory 9
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo level_checkpoint@0.1.2
blyxc native-run level_checkpoint-demo/main.blyx
```

Install with `nest add level_checkpoint@0.1.2` and import `vendor::level_checkpoint::level_checkpoint`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
