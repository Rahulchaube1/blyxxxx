# Piecewise Interp

![Package logo](vendor/piecewise_interp/assets/logo.png)

Linearly interpolate between sorted strictly increasing knots, extending constant values past both ends. Supply matching nonempty arrays.

Scientific and numerical methods · library · 0.1.1

## Function

```blyx
pub fn piecewise_interp(xs: vector, ys: vector, point: f64) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[0,4,8],[1,5,9],2.0` | `3` |
| `[0,4],[1,2],8.0` | `2` |
| `[],[],1.0` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo piecewise_interp@0.1.1
blyxc native-run piecewise_interp-demo/main.blyx
```

Install with `nest add piecewise_interp@0.1.1` and import `vendor::piecewise_interp::piecewise_interp`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
