# Cart Discount

![Package logo](vendor/cart_discount/assets/logo.png)

Calculate a minor-unit discount capped by both an offer maximum and the subtotal. Rates are whole basis points rounded down.

Commerce, allocation and measurement · library · 0.1.1

## Function

```blyx
pub fn cart_discount(subtotal: i64, rate: i64, cap: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `999,1000,500` | `99` |
| `2000,5000,300` | `300` |
| `1,10001,1` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo cart_discount@0.1.1
blyxc native-run cart_discount-demo/main.blyx
```

Install with `nest add cart_discount@0.1.1` and import `vendor::cart_discount::cart_discount`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
