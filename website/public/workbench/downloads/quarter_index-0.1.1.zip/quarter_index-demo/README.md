# Quarter Index

![Package logo](vendor/quarter_index/assets/logo.png)

Map a calendar month to a one-based fiscal quarter for a configurable starting month.

Calendar, time and scheduling · library · 0.1.1

## Function

```blyx
pub fn quarter_index(month: i64, fiscal_start: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `1,4` | `4` |
| `4,4` | `1` |
| `0,4` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo quarter_index@0.1.1
blyxc native-run quarter_index-demo/main.blyx
```

Install with `nest add quarter_index@0.1.1` and import `vendor::quarter_index::quarter_index`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
