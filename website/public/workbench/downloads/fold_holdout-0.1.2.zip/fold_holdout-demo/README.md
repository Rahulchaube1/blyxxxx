# Fold Holdout

![Eurasian nuthatch](vendor/fold_holdout/assets/logo.png)

Fence training and scoring by fold ID so a late training completion cannot score the wrong holdout.

Machine learning and evaluation · framework · 0.1.2

Framework bird: Eurasian nuthatch.

## Drive the workflow

Start with `fold_holdout_start()`. For each event call `fold_holdout_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `fold_holdout_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `fold_holdout_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | fold | always | training | train_partition | x |
| training | fitted | x=r | scoring | score_holdout | r |
| scoring | done | x=r | closed | record_fold | r |
| closed | fold | x>r | training | train_partition | x |
| training | abort | x=r | idle | discard_fit | 0 |

Phase IDs in order from zero: idle, training, scoring, closed.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- fold 1 fitted 1 done 1 fold 2
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo fold_holdout@0.1.2
blyxc native-run fold_holdout-demo/main.blyx
```

Install with `nest add fold_holdout@0.1.2` and import `vendor::fold_holdout::fold_holdout`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
