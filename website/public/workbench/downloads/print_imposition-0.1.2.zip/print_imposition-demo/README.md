# Print Imposition

![Strawberry finch male](vendor/print_imposition/assets/logo.png)

Complete paired front and back impressions before counting a duplex sheet as finished.

Document production and accessibility · framework · 0.1.2

Framework bird: Strawberry finch male.

## Drive the workflow

Start with `print_imposition_start()`. For each event call `print_imposition_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `print_imposition_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `print_imposition_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | sheets | x>0 | front | feed_sheet | x |
| front | printed | always | back | turn_sheet | r |
| back | printed | r>1 | front | feed_sheet | r-1 |
| back | printed | r=1 | done | eject_job | 0 |
| back | jam | always | retry | clear_back_jam | r |
| retry | resume | always | back | print_back | r |

Phase IDs in order from zero: idle, front, back, done, retry.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- sheets 2 printed 0 jam 0 resume 0 printed 0 printed 0 printed 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo print_imposition@0.1.2
blyxc native-run print_imposition-demo/main.blyx
```

Install with `nest add print_imposition@0.1.2` and import `vendor::print_imposition::print_imposition`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
