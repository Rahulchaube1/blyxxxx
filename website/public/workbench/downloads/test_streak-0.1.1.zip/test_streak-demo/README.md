# Test Streak

![Package logo](vendor/test_streak/assets/logo.png)

Find the longest consecutive run of failures in test results encoded as zero for pass and one for failure.

Testing, documents and accessible interfaces · library · 0.1.1

## Function

```blyx
pub fn test_streak(outcomes: vector) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,0,1,1,0]` | `2` |
| `[0,0]` | `0` |
| `[2]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo test_streak@0.1.1
blyxc native-run test_streak-demo/main.blyx
```

Install with `nest add test_streak@0.1.1` and import `vendor::test_streak::test_streak`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
