# Run Mode

![Package logo](vendor/run_mode/assets/logo.png)

Return the most frequent value in a sorted nonempty vector, choosing the smallest value on ties. Empty input returns zero.

Sequence and table processing · library · 0.1.1

## Function

```blyx
pub fn run_mode(items: vector) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,2,2,5,5]` | `2` |
| `[1,1,2,2,2]` | `2` |
| `[]` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo run_mode@0.1.1
blyxc native-run run_mode-demo/main.blyx
```

Install with `nest add run_mode@0.1.1` and import `vendor::run_mode::run_mode`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
