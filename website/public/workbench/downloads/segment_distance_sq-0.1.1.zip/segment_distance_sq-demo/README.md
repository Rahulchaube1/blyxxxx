# Segment Distance Sq

![Package logo](vendor/segment_distance_sq/assets/logo.png)

Return squared Euclidean distance from a point to a closed segment, including the zero-length case.

Geometry, maps and layout · library · 0.1.1

## Function

```blyx
pub fn segment_distance_sq(px: f64, py: f64, ax: f64, ay: f64, bx: f64, by: f64) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `1.0,3.0,0.0,0.0,2.0,0.0` | `9` |
| `4.0,0.0,0.0,0.0,2.0,0.0` | `4` |
| `3.0,4.0,0.0,0.0,0.0,0.0` | `25` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo segment_distance_sq@0.1.1
blyxc native-run segment_distance_sq-demo/main.blyx
```

Install with `nest add segment_distance_sq@0.1.1` and import `vendor::segment_distance_sq::segment_distance_sq`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
