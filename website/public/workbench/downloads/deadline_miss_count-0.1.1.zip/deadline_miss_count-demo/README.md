# Deadline Miss Count

![Package logo](vendor/deadline_miss_count/assets/logo.png)

Count jobs missing absolute deadlines on one nonpreemptive worker in the supplied dispatch order.

Systems, queues and reliability · library · 0.1.1

## Function

```blyx
pub fn deadline_miss_count(duration: vector, deadline: vector) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[3,4,2],[3,6,8]` | `2` |
| `[2],[2]` | `0` |
| `[],[2]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo deadline_miss_count@0.1.1
blyxc native-run deadline_miss_count-demo/main.blyx
```

Install with `nest add deadline_miss_count@0.1.1` and import `vendor::deadline_miss_count::deadline_miss_count`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
