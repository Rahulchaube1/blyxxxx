# Max Slice Sum

![Package logo](vendor/max_slice_sum/assets/logo.png)

Find the largest contiguous sum in a numeric signal, allowing the empty slice with sum zero.

Sequence and table processing · library · 0.1.1

## Function

```blyx
pub fn max_slice_sum(items: vector) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[-2,3,-1,4,-8]` | `6` |
| `[-3,-4]` | `0` |
| `[]` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo max_slice_sum@0.1.1
blyxc native-run max_slice_sum-demo/main.blyx
```

Install with `nest add max_slice_sum@0.1.1` and import `vendor::max_slice_sum::max_slice_sum`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
