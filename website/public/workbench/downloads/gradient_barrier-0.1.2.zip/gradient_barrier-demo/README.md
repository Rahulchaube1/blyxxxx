# Gradient Barrier

![Red-crowned crane](vendor/gradient_barrier/assets/logo.png)

Coordinate a fixed count of host-deduplicated gradient contributions before a single optimizer step.

Machine learning and evaluation · framework · 0.1.2

Framework bird: Red-crowned crane.

## Drive the workflow

Start with `gradient_barrier_start()`. For each event call `gradient_barrier_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `gradient_barrier_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `gradient_barrier_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | workers | x>0 | reducing | start_round | x |
| reducing | contribution | r>1 | reducing | accumulate_one | r-1 |
| reducing | contribution | r=1 | ready | seal_reduction | 0 |
| ready | step | always | applied | apply_optimizer | 0 |
| applied | workers | x>0 | reducing | start_round | x |

Phase IDs in order from zero: idle, reducing, ready, applied.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- workers 2 contribution 0 contribution 0 step 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo gradient_barrier@0.1.2
blyxc native-run gradient_barrier-demo/main.blyx
```

Install with `nest add gradient_barrier@0.1.2` and import `vendor::gradient_barrier::gradient_barrier`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
