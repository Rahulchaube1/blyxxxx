# Focus Next Enabled

![Package logo](vendor/focus_next_enabled/assets/logo.png)

Return the next enabled control index in a circular tab order. Return minus one when every control is disabled or the starting index is invalid.

Testing, documents and accessible interfaces · library · 0.1.1

## Function

```blyx
pub fn focus_next_enabled(enabled: vector, current: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,0,1],2` | `0` |
| `[0,0],0` | `-1` |
| `[0,1],0` | `1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo focus_next_enabled@0.1.1
blyxc native-run focus_next_enabled-demo/main.blyx
```

Install with `nest add focus_next_enabled@0.1.1` and import `vendor::focus_next_enabled::focus_next_enabled`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
