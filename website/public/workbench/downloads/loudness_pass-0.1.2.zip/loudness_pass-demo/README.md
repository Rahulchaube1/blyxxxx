# Loudness Pass

![Egyptian vulture](vendor/loudness_pass/assets/logo.png)

Require a measured peak from a first pass before applying a bounded mastering target.

Audio, images and video · framework · 0.1.2

Framework bird: Egyptian vulture.

## Drive the workflow

Start with `loudness_pass_start()`. For each event call `loudness_pass_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `loudness_pass_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `loudness_pass_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | scan | always | measuring | analyze_peaks | 0 |
| measuring | peak | x>r | measuring | remember_peak | x |
| measuring | finish | r>0 | mixing | request_target | r |
| mixing | target | x<=r | ready | attenuate_by | r-x |
| mixing | target | x>r | ready | boost_by | x-r |
| ready | render | always | done | write_master | r |

Phase IDs in order from zero: idle, measuring, mixing, ready, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- scan 0 peak 80 finish 0 target 65 render 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo loudness_pass@0.1.2
blyxc native-run loudness_pass-demo/main.blyx
```

Install with `nest add loudness_pass@0.1.2` and import `vendor::loudness_pass::loudness_pass`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
