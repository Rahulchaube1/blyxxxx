# Mail Merge Batch

![Hyacinth macaw](vendor/mail_merge_batch/assets/logo.png)

Track unsent records through merge, exclusion and validated spooling of an output batch.

Document production and accessibility · framework · 0.1.2

Framework bird: Hyacinth macaw.

## Drive the workflow

Start with `mail_merge_batch_start()`. For each event call `mail_merge_batch_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `mail_merge_batch_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `mail_merge_batch_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | records | x>0 | merge | load_template | x |
| merge | skip | x>0 and x<=r | merge | exclude_records | r-x |
| merge | rendered | x>0 and x<=r | merge | spool_records | r-x |
| merge | seal | r=0 | sealed | validate_spool | 0 |
| sealed | pass | always | done | deliver_batch | 0 |
| sealed | fail | always | rejected | hold_spool | 0 |

Phase IDs in order from zero: idle, merge, sealed, done, rejected.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- records 4 skip 1 rendered 3 seal 0 pass 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo mail_merge_batch@0.1.2
blyxc native-run mail_merge_batch-demo/main.blyx
```

Install with `nest add mail_merge_batch@0.1.2` and import `vendor::mail_merge_batch::mail_merge_batch`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
