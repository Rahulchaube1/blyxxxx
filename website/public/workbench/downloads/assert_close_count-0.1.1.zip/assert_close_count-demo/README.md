# Assert Close Count

![Package logo](vendor/assert_close_count/assets/logo.png)

Count coordinate deviations exceeding an absolute plus relative reference tolerance. Reject unequal vectors or negative tolerances.

Testing, documents and accessible interfaces · library · 0.1.1

## Function

```blyx
pub fn assert_close_count(actual: vector, reference: vector, atol: f64, rtol: f64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[12,8],[10,8],1.0,0.0` | `1` |
| `[11],[10],0.0,0.1` | `0` |
| `[1],[],0.0,0.0` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo assert_close_count@0.1.1
blyxc native-run assert_close_count-demo/main.blyx
```

Install with `nest add assert_close_count@0.1.1` and import `vendor::assert_close_count::assert_close_count`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
