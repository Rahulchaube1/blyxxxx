# Dark Frame Stack

![White bellbird male](vendor/dark_frame_stack/assets/logo.png)

Acquire a required stack of dark frames and repeat the acquisition when a light leak is detected.

Maps, environment and scientific acquisition · framework · 0.1.2

Framework bird: White bellbird male.

## Drive the workflow

Start with `dark_frame_stack_start()`. For each event call `dark_frame_stack_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `dark_frame_stack_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `dark_frame_stack_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | target | x>0 | collecting | collect_darks | x |
| collecting | dark | r>1 | collecting | store_dark | r-1 |
| collecting | dark | r=1 | reducing | compute_master | 0 |
| collecting | leak | x>0 | collecting | restart_stack | x |
| reducing | accept | always | ready | publish_master | 0 |
| reducing | reject | x>0 | collecting | restart_stack | x |

Phase IDs in order from zero: idle, collecting, reducing, ready.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- target 2 dark 0 leak 2 dark 0 dark 0 accept 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo dark_frame_stack@0.1.2
blyxc native-run dark_frame_stack-demo/main.blyx
```

Install with `nest add dark_frame_stack@0.1.2` and import `vendor::dark_frame_stack::dark_frame_stack`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
