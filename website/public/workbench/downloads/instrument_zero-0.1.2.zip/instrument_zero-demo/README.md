# Instrument Zero

![Pied avocet](vendor/instrument_zero/assets/logo.png)

Apply a zero-offset correction only after repeated reference measurements agree within one count.

Maps, environment and scientific acquisition · framework · 0.1.2

Framework bird: Pied avocet.

## Drive the workflow

Start with `instrument_zero_start()`. For each event call `instrument_zero_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `instrument_zero_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `instrument_zero_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | baseline | always | checking | capture_reference | x |
| checking | confirm | x+1>=r and x<=r+1 | ready | accept_offset | r |
| checking | confirm | always | checking | replace_reference | x |
| ready | drift | x>r+1 | checking | recapture_reference | x |
| ready | use | always | active | apply_offset | r |

Phase IDs in order from zero: idle, checking, ready, active.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- baseline 12 confirm 18 confirm 17 use 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo instrument_zero@0.1.2
blyxc native-run instrument_zero-demo/main.blyx
```

Install with `nest add instrument_zero@0.1.2` and import `vendor::instrument_zero::instrument_zero`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
