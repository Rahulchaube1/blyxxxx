# Split Tender

![African spoonbill](vendor/split_tender/assets/logo.png)

Collect installments in minor units and prevent capture above the outstanding order balance.

Commerce and fulfillment · framework · 0.1.2

Framework bird: African spoonbill.

## Drive the workflow

Start with `split_tender_start()`. For each event call `split_tender_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `split_tender_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `split_tender_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | invoice | x>0 | due | request_payment | x |
| due | pay | x>0 and x<r | due | apply_installment | r-x |
| due | pay | x=r | paid | close_invoice | 0 |
| due | void | always | voided | void_balance | r |

Phase IDs in order from zero: idle, due, paid, voided.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- invoice 100 pay 30 pay 70
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo split_tender@0.1.2
blyxc native-run split_tender-demo/main.blyx
```

Install with `nest add split_tender@0.1.2` and import `vendor::split_tender::split_tender`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
