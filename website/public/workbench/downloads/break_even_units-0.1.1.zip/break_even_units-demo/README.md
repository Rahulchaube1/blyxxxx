# Break Even Units

![Package logo](vendor/break_even_units/assets/logo.png)

Calculate the first whole unit count whose positive contribution margin covers fixed overhead. Return minus one for a nonpositive margin.

Commerce, allocation and measurement · library · 0.1.1

## Function

```blyx
pub fn break_even_units(fixed: i64, unit_price: i64, variable_cost: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `101,20,10` | `11` |
| `100,20,10` | `10` |
| `10,5,5` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo break_even_units@0.1.1
blyxc native-run break_even_units-demo/main.blyx
```

Install with `nest add break_even_units@0.1.1` and import `vendor::break_even_units::break_even_units`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
