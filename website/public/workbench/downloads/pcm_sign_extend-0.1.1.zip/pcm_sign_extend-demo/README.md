# Pcm Sign Extend

![Package logo](vendor/pcm_sign_extend/assets/logo.png)

Interpret an unsigned 16-bit PCM word as a signed sample. Values outside the word range return minus 32769.

Audio and image processing · library · 0.1.1

## Function

```blyx
pub fn pcm_sign_extend(word: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `65535` | `-1` |
| `32768` | `-32768` |
| `65536` | `-32769` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo pcm_sign_extend@0.1.1
blyxc native-run pcm_sign_extend-demo/main.blyx
```

Install with `nest add pcm_sign_extend@0.1.1` and import `vendor::pcm_sign_extend::pcm_sign_extend`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
