# Grid Resample

![Steller's sea eagle](vendor/grid_resample/assets/logo.png)

Track remaining destination rows during raster reprojection and require an explicit nodata audit before release.

Maps, environment and scientific acquisition · framework · 0.1.2

Framework bird: Steller's sea eagle.

## Drive the workflow

Start with `grid_resample_start()`. For each event call `grid_resample_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `grid_resample_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `grid_resample_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | rows | x>0 | sampling | allocate_destination | x |
| sampling | wrote | x>0 and x<=r | sampling | advance_scanline | r-x |
| sampling | finish | r=0 | auditing | count_nodata | 0 |
| auditing | holes | x>0 | repair | request_fill | x |
| repair | filled | x=r | auditing | count_nodata | 0 |
| auditing | holes | x=0 | done | finalize_raster | 0 |

Phase IDs in order from zero: idle, sampling, auditing, repair, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- rows 3 wrote 3 finish 0 holes 2 filled 2 holes 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo grid_resample@0.1.2
blyxc native-run grid_resample-demo/main.blyx
```

Install with `nest add grid_resample@0.1.2` and import `vendor::grid_resample::grid_resample`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
