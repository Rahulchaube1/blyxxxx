# Cycle Count

![Cedar waxwing](vendor/cycle_count/assets/logo.png)

Freeze a bin for a blind stock count and require reconciliation for discrepancies.

Logistics, utilities and production · framework · 0.1.2

Framework bird: Cedar waxwing.

## Drive the workflow

Start with `cycle_count_start()`. For each event call `cycle_count_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `cycle_count_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `cycle_count_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | freeze | always | counting | store_book_qty | x |
| counting | count | x=r | matched | unfreeze_bin | r |
| counting | count | x!=r | dispute | request_recount | r |
| dispute | recount | x=r | matched | unfreeze_bin | r |
| dispute | approve | always | adjusted | adjust_book_qty | x |

Phase IDs in order from zero: idle, counting, matched, dispute, adjusted.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- freeze 14 count 12 recount 14
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo cycle_count@0.1.2
blyxc native-run cycle_count-demo/main.blyx
```

Install with `nest add cycle_count@0.1.2` and import `vendor::cycle_count::cycle_count`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
