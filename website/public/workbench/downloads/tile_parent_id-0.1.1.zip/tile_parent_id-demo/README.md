# Tile Parent Id

![Package logo](vendor/tile_parent_id/assets/logo.png)

Map a row-major square tile ID into its parent in an even-width tile level. Reject invalid IDs and odd widths.

Geometry, maps and layout · library · 0.1.1

## Function

```blyx
pub fn tile_parent_id(tile: i64, width: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `15,4` | `3` |
| `4,4` | `0` |
| `9,3` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo tile_parent_id@0.1.1
blyxc native-run tile_parent_id-demo/main.blyx
```

Install with `nest add tile_parent_id@0.1.1` and import `vendor::tile_parent_id::tile_parent_id`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
