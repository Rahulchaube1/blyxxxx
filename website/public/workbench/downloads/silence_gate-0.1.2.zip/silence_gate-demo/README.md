# Silence Gate

![Emperor penguin](vendor/silence_gate/assets/logo.png)

Use separate open and close amplitude thresholds to prevent chatter in an audio gate.

Audio, images and video · framework · 0.1.2

Framework bird: Emperor penguin.

## Drive the workflow

Start with `silence_gate_start()`. For each event call `silence_gate_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `silence_gate_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `silence_gate_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | configure | x>1 | quiet | set_open_level | x |
| quiet | sample | x>=r | passing | open_gate | r |
| quiet | sample | x<r | quiet | mute | r |
| passing | sample | x*2<=r | quiet | close_gate | r |
| passing | sample | x*2>r | passing | pass_audio | r |

Phase IDs in order from zero: idle, quiet, passing.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- configure 10 sample 9 sample 10 sample 6 sample 5
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo silence_gate@0.1.2
blyxc native-run silence_gate-demo/main.blyx
```

Install with `nest add silence_gate@0.1.2` and import `vendor::silence_gate::silence_gate`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
