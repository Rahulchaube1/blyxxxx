# Simpson Uniform

![Package logo](vendor/simpson_uniform/assets/logo.png)

Integrate an odd number of at least three equally spaced samples with composite Simpson weights. Invalid grids return zero.

Scientific and numerical methods · library · 0.1.1

## Function

```blyx
pub fn simpson_uniform(ys: vector, spacing: f64) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[0,1,4],1.0` | `2.6666666666666665` |
| `[3,3,3,3,3],1.0` | `12` |
| `[2,2],1.0` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo simpson_uniform@0.1.1
blyxc native-run simpson_uniform-demo/main.blyx
```

Install with `nest add simpson_uniform@0.1.1` and import `vendor::simpson_uniform::simpson_uniform`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
