# Absolute Error Mean

![Package logo](vendor/absolute_error_mean/assets/logo.png)

Summarize average absolute deviation between paired targets and predictions. Empty or unequal batches return minus one.

Learning, forecasting and statistics · library · 0.1.1

## Function

```blyx
pub fn absolute_error_mean(actual: vector, predicted: vector) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[2,4],[4,2]` | `2` |
| `[3],[3]` | `0` |
| `[],[]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo absolute_error_mean@0.1.1
blyxc native-run absolute_error_mean-demo/main.blyx
```

Install with `nest add absolute_error_mean@0.1.1` and import `vendor::absolute_error_mean::absolute_error_mean`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
