# Sample Custody

![Splendid fairywren male](vendor/sample_custody/assets/logo.png)

Track custody of a field sample across dispatch and receipt with a matching seal number.

Maps, environment and scientific acquisition · framework · 0.1.2

Framework bird: Splendid fairywren male.

## Drive the workflow

Start with `sample_custody_start()`. For each event call `sample_custody_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `sample_custody_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `sample_custody_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | label | x>0 | sealed | print_seal | x |
| sealed | dispatch | x=r | transit | log_departure | r |
| transit | receive | x=r | stored | confirm_receipt | r |
| transit | receive | x!=r | held | quarantine_sample | r |
| held | reconcile | x=r | stored | release_quarantine | r |
| stored | archive | x=r | done | archive_record | r |

Phase IDs in order from zero: idle, sealed, transit, stored, held, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- label 12 dispatch 12 receive 13 reconcile 12 archive 12
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo sample_custody@0.1.2
blyxc native-run sample_custody-demo/main.blyx
```

Install with `nest add sample_custody@0.1.2` and import `vendor::sample_custody::sample_custody`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
