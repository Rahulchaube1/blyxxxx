# Embargo Clock

![Rhinoceros hornbill](vendor/embargo_clock/assets/logo.png)

Release an embargoed story only after its scheduled timestamp and support postponement.

Publishing and collaboration · framework · 0.1.2

Framework bird: Rhinoceros hornbill.

## Drive the workflow

Start with `embargo_clock_start()`. For each event call `embargo_clock_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `embargo_clock_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `embargo_clock_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | schedule | x>0 | held | store_deadline | x |
| held | postpone | x>r | held | replace_deadline | x |
| held | tick | x<r | held | wait | r |
| held | tick | x>=r | live | release | r |
| held | withdraw | always | idle | discard | 0 |

Phase IDs in order from zero: idle, held, live.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- schedule 60 tick 55 postpone 80 tick 80
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo embargo_clock@0.1.2
blyxc native-run embargo_clock-demo/main.blyx
```

Install with `nest add embargo_clock@0.1.2` and import `vendor::embargo_clock::embargo_clock`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
