# Tab Column

![Package logo](vendor/tab_column/assets/logo.png)

Advance a zero-based text column to the next tab stop for a positive tab width.

Testing, documents and accessible interfaces · library · 0.1.1

## Function

```blyx
pub fn tab_column(column: i64, width: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `4,4` | `8` |
| `3,4` | `4` |
| `0,0` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo tab_column@0.1.1
blyxc native-run tab_column-demo/main.blyx
```

Install with `nest add tab_column@0.1.1` and import `vendor::tab_column::tab_column`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
