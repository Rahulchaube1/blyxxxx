# Signal Energy

![Package logo](vendor/signal_energy/assets/logo.png)

Sum squared amplitudes of a finite signal block for comparing energy across equal-length windows.

Audio and image processing · library · 0.1.1

## Function

```blyx
pub fn signal_energy(samples: vector) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[3,-4]` | `25` |
| `[]` | `0` |
| `[0,0]` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo signal_energy@0.1.1
blyxc native-run signal_energy-demo/main.blyx
```

Install with `nest add signal_energy@0.1.1` and import `vendor::signal_energy::signal_energy`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
