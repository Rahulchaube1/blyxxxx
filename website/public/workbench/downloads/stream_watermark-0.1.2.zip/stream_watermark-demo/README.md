# Stream Watermark

![Northern gannet](vendor/stream_watermark/assets/logo.png)

Advance an event-time watermark monotonically and route late arrivals for correction.

Data systems and queues · framework · 0.1.2

Framework bird: Northern gannet.

## Drive the workflow

Start with `stream_watermark_start()`. For each event call `stream_watermark_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `stream_watermark_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `stream_watermark_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | begin | always | open | seed_watermark | x |
| open | advance | x>r | open | emit_watermark | x |
| open | record | x<r | open | route_late | r |
| open | record | x>=r | open | route_ontime | r |
| open | stop | always | done | flush_windows | r |

Phase IDs in order from zero: idle, open, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- begin 10 record 8 record 10 advance 12 stop 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo stream_watermark@0.1.2
blyxc native-run stream_watermark-demo/main.blyx
```

Install with `nest add stream_watermark@0.1.2` and import `vendor::stream_watermark::stream_watermark`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
