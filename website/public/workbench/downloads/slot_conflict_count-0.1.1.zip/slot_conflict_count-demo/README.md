# Slot Conflict Count

![Package logo](vendor/slot_conflict_count/assets/logo.png)

Count half-open reservations overlapping a proposed half-open time slot. Ignore empty reservations.

Calendar, time and scheduling · library · 0.1.1

## Function

```blyx
pub fn slot_conflict_count(starts: vector, ends: vector, start: f64, finish: f64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[0,5,8],[5,7,9],5.0,8.0` | `1` |
| `[],[],0.0,1.0` | `0` |
| `[],[],1.0,1.0` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo slot_conflict_count@0.1.1
blyxc native-run slot_conflict_count-demo/main.blyx
```

Install with `nest add slot_conflict_count@0.1.1` and import `vendor::slot_conflict_count::slot_conflict_count`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
