# Unit Pack Waste

![Package logo](vendor/unit_pack_waste/assets/logo.png)

Compute spare slots in the final shipping case when a nonnegative order is packed into equal-size cases.

Commerce, allocation and measurement · library · 0.1.1

## Function

```blyx
pub fn unit_pack_waste(quantity: i64, case_size: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `13,6` | `5` |
| `12,6` | `0` |
| `0,0` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo unit_pack_waste@0.1.1
blyxc native-run unit_pack_waste-demo/main.blyx
```

Install with `nest add unit_pack_waste@0.1.1` and import `vendor::unit_pack_waste::unit_pack_waste`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
