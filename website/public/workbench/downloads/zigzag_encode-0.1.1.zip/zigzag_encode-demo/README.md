# Zigzag Encode

![Package logo](vendor/zigzag_encode/assets/logo.png)

Map signed integers to their unsigned ZigZag representation for compact varints. Inputs must fit in signed 32 bits.

Data integrity, identifiers and formats · library · 0.1.1

## Function

```blyx
pub fn zigzag_encode(value: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `-2` | `3` |
| `2` | `4` |
| `0` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo zigzag_encode@0.1.1
blyxc native-run zigzag_encode-demo/main.blyx
```

Install with `nest add zigzag_encode@0.1.1` and import `vendor::zigzag_encode::zigzag_encode`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
