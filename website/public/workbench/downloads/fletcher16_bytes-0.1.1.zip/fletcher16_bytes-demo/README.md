# Fletcher16 Bytes

![Package logo](vendor/fletcher16_bytes/assets/logo.png)

Compute Fletcher-16 on byte values modulo 255. Invalid byte input returns minus one.

Data integrity, identifiers and formats · library · 0.1.1

## Function

```blyx
pub fn fletcher16_bytes(bytes: vector) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,2,3]` | `2566` |
| `[]` | `0` |
| `[256]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo fletcher16_bytes@0.1.1
blyxc native-run fletcher16_bytes-demo/main.blyx
```

Install with `nest add fletcher16_bytes@0.1.1` and import `vendor::fletcher16_bytes::fletcher16_bytes`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
