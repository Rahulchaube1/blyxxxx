# Luhn Digits

![Package logo](vendor/luhn_digits/assets/logo.png)

Validate a sequence of decimal digits against the Luhn check digit, including its final digit.

Data integrity, identifiers and formats · library · 0.1.1

## Function

```blyx
pub fn luhn_digits(digits: vector) -> bool
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[7,9,9,2,7,3,9,8,7,1,3]` | `true` |
| `[7,9,9,2,7,3,9,8,7,1,4]` | `false` |
| `[]` | `false` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo luhn_digits@0.1.1
blyxc native-run luhn_digits-demo/main.blyx
```

Install with `nest add luhn_digits@0.1.1` and import `vendor::luhn_digits::luhn_digits`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
