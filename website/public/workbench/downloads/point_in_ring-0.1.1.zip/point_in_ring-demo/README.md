# Point In Ring

![Package logo](vendor/point_in_ring/assets/logo.png)

Apply an even-odd ray crossing test to an open or closed polygon ring. Supply a query off the boundary.

Geometry, maps and layout · library · 0.1.1

## Function

```blyx
pub fn point_in_ring(xs: vector, ys: vector, x: f64, y: f64) -> bool
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[0,4,4,0],[0,0,4,4],2.0,2.0` | `true` |
| `[0,4,4,0],[0,0,4,4],5.0,2.0` | `false` |
| `[],[],0.0,0.0` | `false` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo point_in_ring@0.1.1
blyxc native-run point_in_ring-demo/main.blyx
```

Install with `nest add point_in_ring@0.1.1` and import `vendor::point_in_ring::point_in_ring`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
