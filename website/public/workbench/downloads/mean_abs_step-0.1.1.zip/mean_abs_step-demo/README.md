# Mean Abs Step

![Package logo](vendor/mean_abs_step/assets/logo.png)

Measure average absolute change between successive readings, yielding zero for a series with fewer than two observations.

Scientific and numerical methods · library · 0.1.1

## Function

```blyx
pub fn mean_abs_step(samples: vector) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[2,5,1]` | `3.5` |
| `[1]` | `0` |
| `[]` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo mean_abs_step@0.1.1
blyxc native-run mean_abs_step-demo/main.blyx
```

Install with `nest add mean_abs_step@0.1.1` and import `vendor::mean_abs_step::mean_abs_step`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
