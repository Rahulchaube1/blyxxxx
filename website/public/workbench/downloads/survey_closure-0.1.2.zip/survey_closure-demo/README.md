# Survey Closure

![Long-tailed tit](vendor/survey_closure/assets/logo.png)

Hold a survey traverse for remeasurement if its reported closure error exceeds the selected tolerance.

Maps, environment and scientific acquisition · framework · 0.1.2

Framework bird: Long-tailed tit.

## Drive the workflow

Start with `survey_closure_start()`. For each event call `survey_closure_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `survey_closure_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `survey_closure_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | tolerance | always | surveying | set_tolerance | x |
| surveying | close | x>r | correcting | request_resurvey | r |
| correcting | repeat | always | surveying | reopen_traverse | r |
| surveying | close | x<=r | accepted | lock_traverse | r |
| accepted | file | always | done | archive_survey | r |

Phase IDs in order from zero: idle, surveying, correcting, accepted, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- tolerance 3 close 4 repeat 0 close 2 file 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo survey_closure@0.1.2
blyxc native-run survey_closure-demo/main.blyx
```

Install with `nest add survey_closure@0.1.2` and import `vendor::survey_closure::survey_closure`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
