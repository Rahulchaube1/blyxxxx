# Cash Rounding

![Package logo](vendor/cash_rounding/assets/logo.png)

Round a nonnegative amount to the nearest cash increment, resolving exact halves upwards.

Commerce, allocation and measurement · library · 0.1.1

## Function

```blyx
pub fn cash_rounding(amount: i64, increment: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `103,5` | `105` |
| `102,5` | `100` |
| `3,2` | `4` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo cash_rounding@0.1.1
blyxc native-run cash_rounding-demo/main.blyx
```

Install with `nest add cash_rounding@0.1.1` and import `vendor::cash_rounding::cash_rounding`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
