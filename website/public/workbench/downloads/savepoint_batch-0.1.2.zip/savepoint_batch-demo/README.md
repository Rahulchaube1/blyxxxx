# Savepoint Batch

![Turquoise-browed motmot](vendor/savepoint_batch/assets/logo.png)

Control a nested transaction using a savepoint depth and reject outer commit before nested scopes close.

Data systems and queues · framework · 0.1.2

Framework bird: Turquoise-browed motmot.

## Drive the workflow

Start with `savepoint_batch_start()`. For each event call `savepoint_batch_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `savepoint_batch_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `savepoint_batch_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | begin | always | active | open_transaction | 0 |
| active | save | always | active | create_savepoint | r+1 |
| active | rewind | r>0 | active | rollback_savepoint | r-1 |
| active | merge | r>0 | active | release_savepoint | r-1 |
| active | commit | r=0 | done | commit_transaction | 0 |
| active | abort | always | done | rollback_transaction | 0 |

Phase IDs in order from zero: idle, active, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- begin 0 save 0 rewind 0 commit 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo savepoint_batch@0.1.2
blyxc native-run savepoint_batch-demo/main.blyx
```

Install with `nest add savepoint_batch@0.1.2` and import `vendor::savepoint_batch::savepoint_batch`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
