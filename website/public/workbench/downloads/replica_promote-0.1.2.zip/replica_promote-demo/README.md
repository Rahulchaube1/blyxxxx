# Replica Promote

![Greater roadrunner](vendor/replica_promote/assets/logo.png)

Fence a replica promotion against its required log offset before announcing a new primary.

Data systems and queues · framework · 0.1.2

Framework bird: Greater roadrunner.

## Drive the workflow

Start with `replica_promote_start()`. For each event call `replica_promote_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `replica_promote_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `replica_promote_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | target | x>0 | catching | poll_replica | x |
| catching | lag | x<r | catching | wait_for_log | r |
| catching | replayed | x>=r | fenced | fence_old_primary | x |
| fenced | confirmed | x=r | ready | enable_writes | r |
| ready | advertise | x=r | live | update_routes | r |

Phase IDs in order from zero: idle, catching, fenced, ready, live.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- target 100 lag 80 replayed 101 confirmed 101 advertise 101
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo replica_promote@0.1.2
blyxc native-run replica_promote-demo/main.blyx
```

Install with `nest add replica_promote@0.1.2` and import `vendor::replica_promote::replica_promote`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
