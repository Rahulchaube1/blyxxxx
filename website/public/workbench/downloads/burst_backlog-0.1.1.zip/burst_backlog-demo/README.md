# Burst Backlog

![Package logo](vendor/burst_backlog/assets/logo.png)

Compute the peak queued work across synchronized arrivals followed by service at each time step. Return minus one for invalid counts.

Systems, queues and reliability · library · 0.1.1

## Function

```blyx
pub fn burst_backlog(arrivals: vector, service: vector) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[4,4],[1,9]` | `7` |
| `[],[]` | `0` |
| `[1],[]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo burst_backlog@0.1.1
blyxc native-run burst_backlog-demo/main.blyx
```

Install with `nest add burst_backlog@0.1.1` and import `vendor::burst_backlog::burst_backlog`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
