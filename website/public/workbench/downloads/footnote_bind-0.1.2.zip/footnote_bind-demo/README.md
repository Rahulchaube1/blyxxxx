# Footnote Bind

![Eurasian blue tit](vendor/footnote_bind/assets/logo.png)

Resolve forward footnote references and block typesetting while the outstanding count is positive.

Document production and accessibility · framework · 0.1.2

Framework bird: Eurasian blue tit.

## Drive the workflow

Start with `footnote_bind_start()`. For each event call `footnote_bind_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `footnote_bind_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `footnote_bind_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | start | always | composing | begin_layout | 0 |
| composing | reference | x>0 | composing | add_unresolved | r+x |
| composing | resolve | x>0 and x<=r | composing | bind_references | r-x |
| composing | typeset | r=0 | proof | render_proof | 0 |
| proof | approve | always | done | export_pages | 0 |

Phase IDs in order from zero: idle, composing, proof, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- start 0 reference 3 resolve 2 resolve 1 typeset 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo footnote_bind@0.1.2
blyxc native-run footnote_bind-demo/main.blyx
```

Install with `nest add footnote_bind@0.1.2` and import `vendor::footnote_bind::footnote_bind`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
