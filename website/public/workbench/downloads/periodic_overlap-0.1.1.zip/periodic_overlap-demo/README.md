# Periodic Overlap

![Package logo](vendor/periodic_overlap/assets/logo.png)

Measure minutes in a recurring daily window, including windows that cross midnight, within one specified minute-of-day interval. Equal daily endpoints mean an empty window.

Calendar, time and scheduling · library · 0.1.1

## Function

```blyx
pub fn periodic_overlap(begin: i64, finish: i64, window_start: i64, window_end: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `0,60,1380,30` | `30` |
| `10,20,5,25` | `10` |
| `0,1440,9,9` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo periodic_overlap@0.1.1
blyxc native-run periodic_overlap-demo/main.blyx
```

Install with `nest add periodic_overlap@0.1.1` and import `vendor::periodic_overlap::periodic_overlap`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
