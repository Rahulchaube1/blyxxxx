# Newton Step

![Package logo](vendor/newton_step/assets/logo.png)

Apply one scalar Newton update to a root estimate with a caller-supplied derivative. Preserve the estimate for a zero derivative.

Scientific and numerical methods · library · 0.1.1

## Function

```blyx
pub fn newton_step(estimate: f64, residual: f64, derivative: f64) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `3.0,5.0,6.0` | `2.1666666666666665` |
| `4.0,0.0,2.0` | `4` |
| `4.0,1.0,0.0` | `4` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo newton_step@0.1.1
blyxc native-run newton_step-demo/main.blyx
```

Install with `nest add newton_step@0.1.1` and import `vendor::newton_step::newton_step`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
