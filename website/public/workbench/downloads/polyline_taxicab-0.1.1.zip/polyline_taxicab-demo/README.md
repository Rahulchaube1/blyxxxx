# Polyline Taxicab

![Package logo](vendor/polyline_taxicab/assets/logo.png)

Measure total Manhattan travel along a rectilinear path. Mismatched coordinate arrays return minus one.

Geometry, maps and layout · library · 0.1.1

## Function

```blyx
pub fn polyline_taxicab(xs: vector, ys: vector) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[0,3,1],[2,2,5]` | `8` |
| `[],[]` | `0` |
| `[1],[]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo polyline_taxicab@0.1.1
blyxc native-run polyline_taxicab-demo/main.blyx
```

Install with `nest add polyline_taxicab@0.1.1` and import `vendor::polyline_taxicab::polyline_taxicab`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
