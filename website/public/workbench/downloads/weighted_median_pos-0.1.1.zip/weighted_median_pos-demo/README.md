# Weighted Median Pos

![Package logo](vendor/weighted_median_pos/assets/logo.png)

Select the first sorted value index whose cumulative nonnegative weight reaches half the total. Zero total returns minus one.

Learning, forecasting and statistics · library · 0.1.1

## Function

```blyx
pub fn weighted_median_pos(weights: vector) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,3,1]` | `1` |
| `[1,1]` | `0` |
| `[0,0]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo weighted_median_pos@0.1.1
blyxc native-run weighted_median_pos-demo/main.blyx
```

Install with `nest add weighted_median_pos@0.1.1` and import `vendor::weighted_median_pos::weighted_median_pos`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
