# Isbn10 Check

![Package logo](vendor/isbn10_check/assets/logo.png)

Validate ten ISBN-10 values in print order. Encode the final X as 10.

Data integrity, identifiers and formats · library · 0.1.1

## Function

```blyx
pub fn isbn10_check(digits: vector) -> bool
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[0,3,0,6,4,0,6,1,5,2]` | `true` |
| `[0,3,0,6,4,0,6,1,5,3]` | `false` |
| `[]` | `false` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo isbn10_check@0.1.1
blyxc native-run isbn10_check-demo/main.blyx
```

Install with `nest add isbn10_check@0.1.1` and import `vendor::isbn10_check::isbn10_check`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
