# Pixel Luma

![Package logo](vendor/pixel_luma/assets/logo.png)

Compute integer BT.601-style luma using fixed weights 77, 150 and 29 with nearest rounding. RGB channels must be bytes.

Audio and image processing · library · 0.1.1

## Function

```blyx
pub fn pixel_luma(red: i64, green: i64, blue: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `255,255,255` | `255` |
| `255,0,0` | `77` |
| `0,256,0` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo pixel_luma@0.1.1
blyxc native-run pixel_luma-demo/main.blyx
```

Install with `nest add pixel_luma@0.1.1` and import `vendor::pixel_luma::pixel_luma`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
