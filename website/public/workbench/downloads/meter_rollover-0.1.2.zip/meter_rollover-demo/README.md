# Meter Rollover

![Rock ptarmigan male](vendor/meter_rollover/assets/logo.png)

Detect dial rollover and report monotonically increasing meter readings or rollover corrections.

Logistics, utilities and production · framework · 0.1.2

Framework bird: Rock ptarmigan male.

## Drive the workflow

Start with `meter_rollover_start()`. For each event call `meter_rollover_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `meter_rollover_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `meter_rollover_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | reading | always | tracking | seed_reading | x |
| tracking | reading | x>=r | tracking | advance_meter | x |
| tracking | reading | x<r | verify | confirm_rollover | r |
| verify | rollover | x<r | tracking | rebase_meter | x |
| verify | correction | x>=r | tracking | replace_reading | x |

Phase IDs in order from zero: idle, tracking, verify.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- reading 98 reading 2 rollover 2 reading 4
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo meter_rollover@0.1.2
blyxc native-run meter_rollover-demo/main.blyx
```

Install with `nest add meter_rollover@0.1.2` and import `vendor::meter_rollover::meter_rollover`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
