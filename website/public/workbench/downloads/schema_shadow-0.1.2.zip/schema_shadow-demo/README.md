# Schema Shadow

![Great crested grebe](vendor/schema_shadow/assets/logo.png)

Protect a shadow-table cutover until the declared row backfill and an explicit consistency check finish.

Data systems and queues · framework · 0.1.2

Framework bird: Great crested grebe.

## Drive the workflow

Start with `schema_shadow_start()`. For each event call `schema_shadow_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `schema_shadow_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `schema_shadow_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | stage | x>0 | copying | create_shadow | x |
| copying | copied | x>0 and x<r | copying | checkpoint_rows | r-x |
| copying | copied | x=r | comparing | compare_tables | 0 |
| comparing | mismatch | x>0 | copying | recopy_rows | x |
| comparing | match | always | ready | lock_cutover | 0 |
| ready | switch | always | done | rename_tables | 0 |

Phase IDs in order from zero: idle, copying, comparing, ready, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- stage 4 copied 4 mismatch 2 copied 2 match 0 switch 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo schema_shadow@0.1.2
blyxc native-run schema_shadow-demo/main.blyx
```

Install with `nest add schema_shadow@0.1.2` and import `vendor::schema_shadow::schema_shadow`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
