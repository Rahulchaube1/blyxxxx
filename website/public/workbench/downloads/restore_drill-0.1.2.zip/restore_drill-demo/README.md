# Restore Drill

![Smew drake](vendor/restore_drill/assets/logo.png)

Verify restored row counts and run a read probe before declaring a recovery drill successful.

Reliability and delivery · framework · 0.1.2

Framework bird: Smew drake.

## Drive the workflow

Start with `restore_drill_start()`. For each event call `restore_drill_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `restore_drill_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `restore_drill_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | restore | always | recovering | load_snapshot | x |
| recovering | count | x!=r | failed | report_count_mismatch | x |
| recovering | count | x=r | probing | run_read_probe | r |
| probing | bad | always | failed | report_probe_failure | r |
| probing | good | always | complete | record_recovery | r |

Phase IDs in order from zero: idle, recovering, failed, probing, complete.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- restore 7 count 7 good 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo restore_drill@0.1.2
blyxc native-run restore_drill-demo/main.blyx
```

Install with `nest add restore_drill@0.1.2` and import `vendor::restore_drill::restore_drill`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
