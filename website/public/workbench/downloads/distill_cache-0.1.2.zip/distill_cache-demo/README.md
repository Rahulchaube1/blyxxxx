# Distill Cache

![Pine grosbeak male](vendor/distill_cache/assets/logo.png)

Seal teacher predictions at a pinned teacher revision and invalidate stale targets when it changes.

Machine learning and evaluation · framework · 0.1.2

Framework bird: Pine grosbeak male.

## Drive the workflow

Start with `distill_cache_start()`. For each event call `distill_cache_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `distill_cache_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `distill_cache_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | teacher | x>0 | caching | generate_targets | x |
| caching | cached | x=r | ready | freeze_targets | r |
| ready | student | x=r | fitting | fit_student | r |
| ready | teacher | x!=r | caching | invalidate_targets | x |
| fitting | finish | x=r | done | save_student | r |

Phase IDs in order from zero: idle, caching, ready, fitting, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- teacher 5 cached 5 teacher 6 cached 6 student 6 finish 6
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo distill_cache@0.1.2
blyxc native-run distill_cache-demo/main.blyx
```

Install with `nest add distill_cache@0.1.2` and import `vendor::distill_cache::distill_cache`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
