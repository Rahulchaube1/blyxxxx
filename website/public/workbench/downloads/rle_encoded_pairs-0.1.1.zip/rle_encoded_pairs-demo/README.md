# Rle Encoded Pairs

![Package logo](vendor/rle_encoded_pairs/assets/logo.png)

Count count-value runs required for a bounded run-length encoding, splitting long repeated runs at the configured maximum.

Testing, documents and accessible interfaces · library · 0.1.1

## Function

```blyx
pub fn rle_encoded_pairs(values: vector, max_run: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,1,1,2,2],2` | `3` |
| `[],2` | `0` |
| `[1],0` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo rle_encoded_pairs@0.1.1
blyxc native-run rle_encoded_pairs-demo/main.blyx
```

Install with `nest add rle_encoded_pairs@0.1.1` and import `vendor::rle_encoded_pairs::rle_encoded_pairs`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
