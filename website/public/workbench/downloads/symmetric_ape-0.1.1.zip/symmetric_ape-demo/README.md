# Symmetric Ape

![Package logo](vendor/symmetric_ape/assets/logo.png)

Compute mean symmetric absolute percentage error on a 0 to 200 scale with zero contribution when both values are zero.

Learning, forecasting and statistics · library · 0.1.1

## Function

```blyx
pub fn symmetric_ape(actual: vector, predicted: vector) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[0,2],[0,0]` | `100` |
| `[-1],[1]` | `200` |
| `[],[]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo symmetric_ape@0.1.1
blyxc native-run symmetric_ape-demo/main.blyx
```

Install with `nest add symmetric_ape@0.1.1` and import `vendor::symmetric_ape::symmetric_ape`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
