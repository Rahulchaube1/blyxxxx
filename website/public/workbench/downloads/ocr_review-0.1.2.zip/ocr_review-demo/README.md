# Ocr Review

![Great blue turaco](vendor/ocr_review/assets/logo.png)

Route pages below a caller-provided confidence cutoff to human correction before indexing.

Document production and accessibility · framework · 0.1.2

Framework bird: Great blue turaco.

## Drive the workflow

Start with `ocr_review_start()`. For each event call `ocr_review_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `ocr_review_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `ocr_review_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | cutoff | x<=100 | ready | set_confidence | x |
| ready | score | x>=r and x<=100 | indexing | index_text | r |
| ready | score | x<r | review | request_correction | r |
| review | corrected | always | indexing | index_text | r |
| indexing | next | always | ready | read_page | r |

Phase IDs in order from zero: idle, ready, indexing, review.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- cutoff 85 score 79 corrected 0 next 0 score 91
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo ocr_review@0.1.2
blyxc native-run ocr_review-demo/main.blyx
```

Install with `nest add ocr_review@0.1.2` and import `vendor::ocr_review::ocr_review`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
