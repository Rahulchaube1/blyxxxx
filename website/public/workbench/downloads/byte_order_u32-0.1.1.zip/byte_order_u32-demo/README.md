# Byte Order U32

![Package logo](vendor/byte_order_u32/assets/logo.png)

Decode four validated bytes beginning at an offset into an unsigned big-endian 32-bit value represented exactly in FP64.

Data integrity, identifiers and formats · library · 0.1.1

## Function

```blyx
pub fn byte_order_u32(bytes: vector, offset: i64) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[0,1,2,3],0` | `66051` |
| `[9,0,0,0,5],1` | `5` |
| `[],0` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo byte_order_u32@0.1.1
blyxc native-run byte_order_u32-demo/main.blyx
```

Install with `nest add byte_order_u32@0.1.1` and import `vendor::byte_order_u32::byte_order_u32`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
