# Positive Rank Auc

![Package logo](vendor/positive_rank_auc/assets/logo.png)

Compute binary ROC AUC by positive-negative score comparisons with half credit for ties. Undefined classes return minus one.

Learning, forecasting and statistics · library · 0.1.1

## Function

```blyx
pub fn positive_rank_auc(labels: vector, scores: vector) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,0],[4,4]` | `0.5` |
| `[0,1],[2,3]` | `1` |
| `[1],[5]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo positive_rank_auc@0.1.1
blyxc native-run positive_rank_auc-demo/main.blyx
```

Install with `nest add positive_rank_auc@0.1.1` and import `vendor::positive_rank_auc::positive_rank_auc`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
