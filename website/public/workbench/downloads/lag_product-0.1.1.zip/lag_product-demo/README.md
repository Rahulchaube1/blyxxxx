# Lag Product

![Package logo](vendor/lag_product/assets/logo.png)

Compute the unnormalized autocorrelation sum at a nonnegative integer lag. A missing overlap contributes zero.

Audio and image processing · library · 0.1.1

## Function

```blyx
pub fn lag_product(samples: vector, lag: i64) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,2,3],1` | `8` |
| `[1,2,3],0` | `14` |
| `[3],1` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo lag_product@0.1.1
blyxc native-run lag_product-demo/main.blyx
```

Install with `nest add lag_product@0.1.1` and import `vendor::lag_product::lag_product`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
