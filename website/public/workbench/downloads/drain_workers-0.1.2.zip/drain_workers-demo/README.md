# Drain Workers

![Black-capped chickadee](vendor/drain_workers/assets/logo.png)

Stop new admissions before draining the known count of active workers and terminating a deployment.

Reliability and delivery · framework · 0.1.2

Framework bird: Black-capped chickadee.

## Drive the workflow

Start with `drain_workers_start()`. For each event call `drain_workers_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `drain_workers_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `drain_workers_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | drain | always | draining | disable_admission | x |
| draining | finished | x>0 and x<=r | draining | release_workers | r-x |
| draining | stop | r=0 | done | terminate | 0 |
| draining | abort | always | idle | enable_admission | 0 |

Phase IDs in order from zero: idle, draining, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- drain 3 finished 3 stop 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo drain_workers@0.1.2
blyxc native-run drain_workers-demo/main.blyx
```

Install with `nest add drain_workers@0.1.2` and import `vendor::drain_workers::drain_workers`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
