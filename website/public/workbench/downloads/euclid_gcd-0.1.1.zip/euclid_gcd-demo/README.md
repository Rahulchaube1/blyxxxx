# Euclid Gcd

![Package logo](vendor/euclid_gcd/assets/logo.png)

Find the greatest common divisor of two nonnegative integral measurements using Euclid's remainder algorithm.

Scientific and numerical methods · library · 0.1.1

## Function

```blyx
pub fn euclid_gcd(left: i64, right: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `84,30` | `6` |
| `0,8` | `8` |
| `0,0` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo euclid_gcd@0.1.1
blyxc native-run euclid_gcd-demo/main.blyx
```

Install with `nest add euclid_gcd@0.1.1` and import `vendor::euclid_gcd::euclid_gcd`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
