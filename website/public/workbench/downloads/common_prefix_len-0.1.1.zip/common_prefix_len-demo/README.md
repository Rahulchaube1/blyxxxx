# Common Prefix Len

![Package logo](vendor/common_prefix_len/assets/logo.png)

Find the length of the shared leading sequence of two numeric ID streams before producing a diff.

Sequence and table processing · library · 0.1.1

## Function

```blyx
pub fn common_prefix_len(left: vector, right: vector) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[4,7,9],[4,7,8]` | `2` |
| `[],[1]` | `0` |
| `[1],[1,2]` | `1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo common_prefix_len@0.1.1
blyxc native-run common_prefix_len-demo/main.blyx
```

Install with `nest add common_prefix_len@0.1.1` and import `vendor::common_prefix_len::common_prefix_len`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
