# Game Rounds

![Lady Amherst's pheasant male](vendor/game_rounds/assets/logo.png)

Advance a fixed-length round counter through scoring, disputes and finalization.

Interactive software, games and device clients · framework · 0.1.2

Framework bird: Lady Amherst's pheasant male.

## Drive the workflow

Start with `game_rounds_start()`. For each event call `game_rounds_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `game_rounds_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `game_rounds_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | rounds | x>0 | playing | start_round | x |
| playing | score | always | review | confirm_score | r |
| review | challenge | always | playing | replay_round | r |
| review | accept | r>1 | playing | next_round | r-1 |
| review | accept | r=1 | done | close_series | 0 |

Phase IDs in order from zero: idle, playing, review, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- rounds 2 score 0 challenge 0 score 0 accept 0 score 0 accept 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo game_rounds@0.1.2
blyxc native-run game_rounds-demo/main.blyx
```

Install with `nest add game_rounds@0.1.2` and import `vendor::game_rounds::game_rounds`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
