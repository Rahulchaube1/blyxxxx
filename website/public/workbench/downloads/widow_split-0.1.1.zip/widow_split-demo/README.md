# Widow Split

![Package logo](vendor/widow_split/assets/logo.png)

Choose the largest paragraph prefix that fits while leaving a minimum count on each side. Zero means defer the paragraph to the next page.

Testing, documents and accessible interfaces · library · 0.1.1

## Function

```blyx
pub fn widow_split(lines: i64, room: i64, minimum: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `7,6,2` | `5` |
| `3,2,2` | `0` |
| `2,4,2` | `2` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo widow_split@0.1.1
blyxc native-run widow_split-demo/main.blyx
```

Install with `nest add widow_split@0.1.1` and import `vendor::widow_split::widow_split`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
