# Offline Drafts

![Palm cockatoo](vendor/offline_drafts/assets/logo.png)

Accumulate offline edits and keep dirty status until the uploaded revision is acknowledged.

Interactive software, games and device clients · framework · 0.1.2

Framework bird: Palm cockatoo.

## Drive the workflow

Start with `offline_drafts_start()`. For each event call `offline_drafts_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `offline_drafts_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `offline_drafts_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | edit | x>0 | dirty | cache_revision | x |
| dirty | edit | x>r | dirty | replace_local | x |
| dirty | online | always | syncing | upload_revision | r |
| syncing | edit | x>r | dirty | replace_local | x |
| syncing | ack | x=r | clean | mark_synced | r |
| clean | edit | x>r | dirty | cache_revision | x |

Phase IDs in order from zero: idle, dirty, syncing, clean.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- edit 3 online 0 edit 4 online 0 ack 4
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo offline_drafts@0.1.2
blyxc native-run offline_drafts-demo/main.blyx
```

Install with `nest add offline_drafts@0.1.2` and import `vendor::offline_drafts::offline_drafts`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
