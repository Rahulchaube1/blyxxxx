# Outbox Delivery

![Common redpoll male](vendor/outbox_delivery/assets/logo.png)

Coordinate durable outbox insertion, delivery and acknowledgement with a stable message ID.

Data systems and queues · framework · 0.1.2

Framework bird: Common redpoll male.

## Drive the workflow

Start with `outbox_delivery_start()`. For each event call `outbox_delivery_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `outbox_delivery_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `outbox_delivery_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | enqueue | x>0 | staged | persist_message | x |
| staged | commit | x=r | ready | notify_worker | r |
| staged | rollback | x=r | idle | discard | 0 |
| ready | claim | x=r | sending | send_message | r |
| sending | retry | x=r | ready | notify_worker | r |
| sending | ack | x=r | done | mark_delivered | r |

Phase IDs in order from zero: idle, staged, ready, sending, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- enqueue 4 commit 4 claim 4 retry 4 claim 4 ack 4
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo outbox_delivery@0.1.2
blyxc native-run outbox_delivery-demo/main.blyx
```

Install with `nest add outbox_delivery@0.1.2` and import `vendor::outbox_delivery::outbox_delivery`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
