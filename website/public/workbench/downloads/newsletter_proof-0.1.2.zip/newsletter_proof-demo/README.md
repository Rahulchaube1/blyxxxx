# Newsletter Proof

![Atlantic puffin](vendor/newsletter_proof/assets/logo.png)

Invalidate a newsletter proof after a revision and bind the send request to the approved proof.

Publishing and collaboration · framework · 0.1.2

Framework bird: Atlantic puffin.

## Drive the workflow

Start with `newsletter_proof_start()`. For each event call `newsletter_proof_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `newsletter_proof_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `newsletter_proof_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | render | x>0 | proof | send_test | x |
| proof | edit | x>r | proof | resend_test | x |
| proof | confirm | x=r | armed | allow_send | r |
| armed | edit | x>r | proof | resend_test | x |
| armed | dispatch | x=r | sent | send_issue | r |

Phase IDs in order from zero: idle, proof, armed, sent.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- render 1 confirm 1 edit 2 confirm 2 dispatch 2
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo newsletter_proof@0.1.2
blyxc native-run newsletter_proof-demo/main.blyx
```

Install with `nest add newsletter_proof@0.1.2` and import `vendor::newsletter_proof::newsletter_proof`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
