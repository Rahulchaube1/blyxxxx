# Utf8 Width

![Package logo](vendor/utf8_width/assets/logo.png)

Return the byte width of a Unicode scalar encoded as UTF-8. Reject surrogate code points and values beyond Unicode.

Data integrity, identifiers and formats · library · 0.1.1

## Function

```blyx
pub fn utf8_width(scalar: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `128512` | `4` |
| `65` | `1` |
| `55296` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo utf8_width@0.1.1
blyxc native-run utf8_width-demo/main.blyx
```

Install with `nest add utf8_width@0.1.1` and import `vendor::utf8_width::utf8_width`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
