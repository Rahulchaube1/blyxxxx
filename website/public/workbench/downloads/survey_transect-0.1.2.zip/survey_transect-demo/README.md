# Survey Transect

![Saddle-billed stork](vendor/survey_transect/assets/logo.png)

Visit field waypoints in order and distinguish revisits from the next required station.

Maps, environment and scientific acquisition · framework · 0.1.2

Framework bird: Saddle-billed stork.

## Drive the workflow

Start with `survey_transect_start()`. For each event call `survey_transect_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `survey_transect_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `survey_transect_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | start | always | route | set_first_station | x |
| route | visit | x=r | route | log_station | r+1 |
| route | visit | x<r | route | log_revisit | r |
| route | visit | x>r | route | flag_skipped_station | r |
| route | finish | x=r | done | seal_survey | r |

Phase IDs in order from zero: idle, route, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- start 1 visit 1 visit 3 visit 2 visit 1 finish 3
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo survey_transect@0.1.2
blyxc native-run survey_transect-demo/main.blyx
```

Install with `nest add survey_transect@0.1.2` and import `vendor::survey_transect::survey_transect`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
