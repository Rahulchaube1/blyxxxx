# Inventory Days

![Package logo](vendor/inventory_days/assets/logo.png)

Find the first demand period that cannot be filled from current stock. Return the number of fully served periods.

Commerce, allocation and measurement · library · 0.1.1

## Function

```blyx
pub fn inventory_days(stock: f64, demand: vector) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `7.0,[3,4,1]` | `2` |
| `0.0,[0,1]` | `1` |
| `2.0,[]` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo inventory_days@0.1.1
blyxc native-run inventory_days-demo/main.blyx
```

Install with `nest add inventory_days@0.1.1` and import `vendor::inventory_days::inventory_days`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
