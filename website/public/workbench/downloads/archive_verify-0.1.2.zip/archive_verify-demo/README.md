# Archive Verify

![Spectacled owl](vendor/archive_verify/assets/logo.png)

Compare uncompressed member counts and request integrity checks before accepting a document archive.

Document production and accessibility · framework · 0.1.2

Framework bird: Spectacled owl.

## Drive the workflow

Start with `archive_verify_start()`. For each event call `archive_verify_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `archive_verify_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `archive_verify_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | manifest | x>0 | unpacking | open_archive | x |
| unpacking | member | r>0 | unpacking | count_member | r-1 |
| unpacking | finish | r=0 | verifying | check_crcs | 0 |
| verifying | damaged | x>0 | rejected | report_bad_members | x |
| verifying | damaged | x=0 | accepted | accept_archive | 0 |

Phase IDs in order from zero: idle, unpacking, verifying, rejected, accepted.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- manifest 2 member 0 member 0 finish 0 damaged 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo archive_verify@0.1.2
blyxc native-run archive_verify-demo/main.blyx
```

Install with `nest add archive_verify@0.1.2` and import `vendor::archive_verify::archive_verify`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
