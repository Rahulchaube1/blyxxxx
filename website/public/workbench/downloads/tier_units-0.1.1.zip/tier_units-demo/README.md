# Tier Units

![Package logo](vendor/tier_units/assets/logo.png)

Count units charged inside one progressive pricing tier with excluded lower and included upper cumulative boundaries.

Commerce, allocation and measurement · library · 0.1.1

## Function

```blyx
pub fn tier_units(quantity: i64, lower: i64, upper: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `25,10,20` | `10` |
| `14,10,20` | `4` |
| `9,10,20` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo tier_units@0.1.1
blyxc native-run tier_units-demo/main.blyx
```

Install with `nest add tier_units@0.1.1` and import `vendor::tier_units::tier_units`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
