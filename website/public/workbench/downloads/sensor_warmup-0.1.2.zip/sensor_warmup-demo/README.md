# Sensor Warmup

![Snow bunting male](vendor/sensor_warmup/assets/logo.png)

Hold measurements during a sensor warm-up countdown and restart calibration after a reset.

Maps, environment and scientific acquisition · framework · 0.1.2

Framework bird: Snow bunting male.

## Drive the workflow

Start with `sensor_warmup_start()`. For each event call `sensor_warmup_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `sensor_warmup_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `sensor_warmup_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | power | x>0 | warming | discard_initial | x |
| warming | sample | r>1 | warming | discard_sample | r-1 |
| warming | sample | r=1 | ready | signal_ready | 0 |
| ready | sample | always | ready | store_sample | x |
| ready | reset | x>0 | warming | discard_initial | x |

Phase IDs in order from zero: idle, warming, ready.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- power 2 sample 33 sample 35 sample 36
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo sensor_warmup@0.1.2
blyxc native-run sensor_warmup-demo/main.blyx
```

Install with `nest add sensor_warmup@0.1.2` and import `vendor::sensor_warmup::sensor_warmup`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
