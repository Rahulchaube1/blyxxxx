# Longitude Delta

![Package logo](vendor/longitude_delta/assets/logo.png)

Find the shortest signed longitude change in degrees in the half-open interval from minus 180 to 180.

Geometry, maps and layout · library · 0.1.1

## Function

```blyx
pub fn longitude_delta(start: f64, finish: f64) -> f64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `170.0,-170.0` | `20` |
| `-170.0,170.0` | `-20` |
| `0.0,180.0` | `-180` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo longitude_delta@0.1.1
blyxc native-run longitude_delta-demo/main.blyx
```

Install with `nest add longitude_delta@0.1.1` and import `vendor::longitude_delta::longitude_delta`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
