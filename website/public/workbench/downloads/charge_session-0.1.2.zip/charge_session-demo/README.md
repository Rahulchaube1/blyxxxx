# Charge Session

![Royal flycatcher](vendor/charge_session/assets/logo.png)

Schedule a battery charging session to a target percentage with pause, resume and completion.

Logistics, utilities and production · framework · 0.1.2

Framework bird: Royal flycatcher.

## Drive the workflow

Start with `charge_session_start()`. For each event call `charge_session_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `charge_session_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `charge_session_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | target | x>0 and x<=100 | charging | enable_charger | x |
| charging | level | x<r | charging | continue_charge | r |
| charging | level | x>=r and x<=100 | done | disable_charger | r |
| charging | pause | always | paused | disable_charger | r |
| paused | resume | always | charging | enable_charger | r |

Phase IDs in order from zero: idle, charging, done, paused.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- target 80 level 70 pause 0 resume 0 level 80
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo charge_session@0.1.2
blyxc native-run charge_session-demo/main.blyx
```

Install with `nest add charge_session@0.1.2` and import `vendor::charge_session::charge_session`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
