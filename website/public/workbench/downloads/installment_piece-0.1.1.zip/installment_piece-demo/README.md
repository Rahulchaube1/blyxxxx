# Installment Piece

![Package logo](vendor/installment_piece/assets/logo.png)

Distribute minor units across equal installments, assigning one extra unit to each earliest installment until the remainder is exhausted.

Commerce, allocation and measurement · library · 0.1.1

## Function

```blyx
pub fn installment_piece(amount: i64, count: i64, index: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `10,3,0` | `4` |
| `10,3,2` | `3` |
| `10,3,3` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo installment_piece@0.1.1
blyxc native-run installment_piece-demo/main.blyx
```

Install with `nest add installment_piece@0.1.1` and import `vendor::installment_piece::installment_piece`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
