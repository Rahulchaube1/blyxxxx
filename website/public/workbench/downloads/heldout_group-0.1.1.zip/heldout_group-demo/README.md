# Heldout Group

![Package logo](vendor/heldout_group/assets/logo.png)

Identify the nth distinct group in first-seen order for leave-one-group-out validation. Return its first row index or minus one.

Learning, forecasting and statistics · library · 0.1.1

## Function

```blyx
pub fn heldout_group(groups: vector, fold: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[7,7,2,7,9],2` | `4` |
| `[7,7],1` | `-1` |
| `[4],0` | `0` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo heldout_group@0.1.1
blyxc native-run heldout_group-demo/main.blyx
```

Install with `nest add heldout_group@0.1.1` and import `vendor::heldout_group::heldout_group`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
