# Bracket Depth

![Package logo](vendor/bracket_depth/assets/logo.png)

Check a stream encoded as plus one for open and minus one for close and return maximum balanced nesting. Reject premature closes and unfinished groups.

Testing, documents and accessible interfaces · library · 0.1.1

## Function

```blyx
pub fn bracket_depth(tokens: vector) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,1,-1,-1]` | `2` |
| `[-1,1]` | `-1` |
| `[1]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo bracket_depth@0.1.1
blyxc native-run bracket_depth-demo/main.blyx
```

Install with `nest add bracket_depth@0.1.1` and import `vendor::bracket_depth::bracket_depth`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
