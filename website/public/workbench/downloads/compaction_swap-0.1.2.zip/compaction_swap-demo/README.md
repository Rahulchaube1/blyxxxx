# Compaction Swap

![Roseate spoonbill](vendor/compaction_swap/assets/logo.png)

Retain old table segments until the replacement file has the expected record count and readers drain.

Data systems and queues · framework · 0.1.2

Framework bird: Roseate spoonbill.

## Drive the workflow

Start with `compaction_swap_start()`. For each event call `compaction_swap_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `compaction_swap_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `compaction_swap_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | plan | x>0 | writing | write_segment | x |
| writing | finish | x=r | draining | swap_segment | r |
| writing | finish | x!=r | failed | discard_new | r |
| draining | readers | x>0 | draining | wait_readers | x |
| draining | readers | x=0 | done | unlink_old | 0 |

Phase IDs in order from zero: idle, writing, draining, failed, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- plan 9 finish 9 readers 2 readers 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo compaction_swap@0.1.2
blyxc native-run compaction_swap-demo/main.blyx
```

Install with `nest add compaction_swap@0.1.2` and import `vendor::compaction_swap::compaction_swap`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
