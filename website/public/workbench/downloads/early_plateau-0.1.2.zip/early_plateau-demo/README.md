# Early Plateau

![Purple gallinule](vendor/early_plateau/assets/logo.png)

Track consecutive unimproved evaluations against a caller-selected patience budget.

Machine learning and evaluation · framework · 0.1.2

Framework bird: Purple gallinule.

## Drive the workflow

Start with `early_plateau_start()`. For each event call `early_plateau_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `early_plateau_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `early_plateau_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | patience | x>0 | training | start_monitor | x |
| training | flat | r>1 | training | consume_patience | r-1 |
| training | flat | r=1 | stopped | stop_training | 0 |
| training | improved | x>0 | training | reset_patience | x |
| training | limit | always | stopped | save_final | r |

Phase IDs in order from zero: idle, training, stopped.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- patience 2 flat 0 improved 2 flat 0 flat 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo early_plateau@0.1.2
blyxc native-run early_plateau-demo/main.blyx
```

Install with `nest add early_plateau@0.1.2` and import `vendor::early_plateau::early_plateau`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
