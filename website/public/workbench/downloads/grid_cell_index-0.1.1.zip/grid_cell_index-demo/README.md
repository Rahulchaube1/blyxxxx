# Grid Cell Index

![Package logo](vendor/grid_cell_index/assets/logo.png)

Map an in-bounds integer cell into a zero-based row-major array with explicit dimension checks.

Geometry, maps and layout · library · 0.1.1

## Function

```blyx
pub fn grid_cell_index(x: i64, y: i64, width: i64, height: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `2,1,4,3` | `6` |
| `0,0,1,1` | `0` |
| `4,0,4,3` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo grid_cell_index@0.1.1
blyxc native-run grid_cell_index-demo/main.blyx
```

Install with `nest add grid_cell_index@0.1.1` and import `vendor::grid_cell_index::grid_cell_index`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
