# Chapter Lock

![Superb lyrebird male](vendor/chapter_lock/assets/logo.png)

Prevent a book export from racing a new chapter edit by sealing a numbered manuscript snapshot.

Publishing and collaboration · framework · 0.1.2

Framework bird: Superb lyrebird male.

## Drive the workflow

Start with `chapter_lock_start()`. For each event call `chapter_lock_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `chapter_lock_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `chapter_lock_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | edit | x>r | idle | record_revision | x |
| idle | seal | x=r and r>0 | sealed | freeze_manuscript | r |
| sealed | export | x=r | exporting | render_book | r |
| exporting | fail | x=r | sealed | retry_export | r |
| exporting | finish | x=r | issued | index_edition | r |
| sealed | unseal | always | idle | permit_edits | r |

Phase IDs in order from zero: idle, sealed, exporting, issued.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- edit 2 seal 2 export 2 finish 2
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo chapter_lock@0.1.2
blyxc native-run chapter_lock-demo/main.blyx
```

Install with `nest add chapter_lock@0.1.2` and import `vendor::chapter_lock::chapter_lock`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
