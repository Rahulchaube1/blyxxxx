# Embedding Reindex

![African pygmy kingfisher](vendor/embedding_reindex/assets/logo.png)

Build and verify a new embedding index without routing queries to partially ingested vectors.

Machine learning and evaluation · framework · 0.1.2

Framework bird: African pygmy kingfisher.

## Drive the workflow

Start with `embedding_reindex_start()`. For each event call `embedding_reindex_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `embedding_reindex_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `embedding_reindex_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | documents | x>0 | ingest | build_index | x |
| ingest | vectors | x>0 and x<=r | ingest | add_vectors | r-x |
| ingest | finish | r=0 | testing | probe_search | 0 |
| testing | bad | x>0 | ingest | repair_vectors | x |
| testing | good | always | ready | swap_alias | 0 |
| ready | retire | always | done | delete_old_index | 0 |

Phase IDs in order from zero: idle, ingest, testing, ready, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- documents 2 vectors 2 finish 0 bad 1 vectors 1 finish 0 good 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo embedding_reindex@0.1.2
blyxc native-run embedding_reindex-demo/main.blyx
```

Install with `nest add embedding_reindex@0.1.2` and import `vendor::embedding_reindex::embedding_reindex`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
