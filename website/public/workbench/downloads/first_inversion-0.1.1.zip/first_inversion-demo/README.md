# First Inversion

![Package logo](vendor/first_inversion/assets/logo.png)

Return the zero-based index of the first row that breaks ascending order, or minus one when sorted.

Sequence and table processing · library · 0.1.1

## Function

```blyx
pub fn first_inversion(items: vector) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[1,3,3,2]` | `3` |
| `[4,4]` | `-1` |
| `[]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo first_inversion@0.1.1
blyxc native-run first_inversion-demo/main.blyx
```

Install with `nest add first_inversion@0.1.1` and import `vendor::first_inversion::first_inversion`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
