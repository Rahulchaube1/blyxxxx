# Focus Trap

![Laughing kookaburra](vendor/focus_trap/assets/logo.png)

Cycle keyboard focus around a modal boundary and release focus on dismissal.

Interactive software, games and device clients · framework · 0.1.2

Framework bird: Laughing kookaburra.

## Drive the workflow

Start with `focus_trap_start()`. For each event call `focus_trap_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `focus_trap_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `focus_trap_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | modal | x>0 | active | store_focus_count | x |
| active | forward | x+1=r | active | wrap_first | r |
| active | forward | x+1<r | active | advance_focus | r |
| active | back | x=0 | active | wrap_last | r |
| active | back | x>0 and x<r | active | retreat_focus | r |
| active | dismiss | always | idle | restore_origin | 0 |

Phase IDs in order from zero: idle, active.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- modal 3 forward 2 back 0 forward 0 dismiss 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo focus_trap@0.1.2
blyxc native-run focus_trap-demo/main.blyx
```

Install with `nest add focus_trap@0.1.2` and import `vendor::focus_trap::focus_trap`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
