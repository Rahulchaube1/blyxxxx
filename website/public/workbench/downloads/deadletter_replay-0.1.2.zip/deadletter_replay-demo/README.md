# Deadletter Replay

![Snowy egret](vendor/deadletter_replay/assets/logo.png)

Replay a dead-letter batch with an explicit per-message attempt budget and manual escalation.

Data systems and queues · framework · 0.1.2

Framework bird: Snowy egret.

## Drive the workflow

Start with `deadletter_replay_start()`. For each event call `deadletter_replay_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `deadletter_replay_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `deadletter_replay_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | inspect | x>0 | ready | reserve_attempts | x |
| ready | dispatch | r>0 | waiting | redeliver | r-1 |
| waiting | fail | r>0 | ready | schedule_retry | r |
| waiting | fail | r=0 | parked | require_operator | 0 |
| waiting | ack | always | done | resolve_message | r |
| parked | rearm | x>0 | ready | reserve_attempts | x |

Phase IDs in order from zero: idle, ready, waiting, parked, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- inspect 2 dispatch 0 fail 0 dispatch 0 fail 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo deadletter_replay@0.1.2
blyxc native-run deadletter_replay-demo/main.blyx
```

Install with `nest add deadletter_replay@0.1.2` and import `vendor::deadletter_replay::deadletter_replay`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
