# Weekday Mask Count

![Package logo](vendor/weekday_mask_count/assets/logo.png)

Count allowed weekdays in a half-open span using a seven-value flag vector and the supplied starting weekday from zero to six.

Calendar, time and scheduling · library · 0.1.1

## Function

```blyx
pub fn weekday_mask_count(start_day: i64, days: i64, enabled: vector) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `4,4,[1,1,1,1,1,0,0]` | `2` |
| `0,14,[1,1,1,1,1,0,0]` | `10` |
| `7,2,[1]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo weekday_mask_count@0.1.1
blyxc native-run weekday_mask_count-demo/main.blyx
```

Install with `nest add weekday_mask_count@0.1.1` and import `vendor::weekday_mask_count::weekday_mask_count`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
