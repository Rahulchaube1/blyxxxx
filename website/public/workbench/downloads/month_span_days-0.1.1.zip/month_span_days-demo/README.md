# Month Span Days

![Package logo](vendor/month_span_days/assets/logo.png)

Return the Gregorian length of a named month for positive civil years. Invalid months and years return minus one.

Calendar, time and scheduling · library · 0.1.1

## Function

```blyx
pub fn month_span_days(year: i64, month: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `2000,2` | `29` |
| `1900,2` | `28` |
| `2026,13` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo month_span_days@0.1.1
blyxc native-run month_span_days-demo/main.blyx
```

Install with `nest add month_span_days@0.1.1` and import `vendor::month_span_days::month_span_days`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
