# Locale Bundle

![Lilac-breasted roller](vendor/locale_bundle/assets/logo.png)

Collect a declared number of translated segments and hold publication while segments remain.

Publishing and collaboration · framework · 0.1.2

Framework bird: Lilac-breasted roller.

## Drive the workflow

Start with `locale_bundle_start()`. For each event call `locale_bundle_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `locale_bundle_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `locale_bundle_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | declare | x>0 | collecting | request_segments | x |
| collecting | deliver | x>0 and x<r | collecting | accept_partial | r-x |
| collecting | deliver | x=r | ready | seal_bundle | 0 |
| ready | reopen | x>0 | collecting | request_segments | x |
| ready | publish | always | live | expose_bundle | 0 |

Phase IDs in order from zero: idle, collecting, ready, live.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- declare 4 deliver 1 deliver 3 publish 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo locale_bundle@0.1.2
blyxc native-run locale_bundle-demo/main.blyx
```

Install with `nest add locale_bundle@0.1.2` and import `vendor::locale_bundle::locale_bundle`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
