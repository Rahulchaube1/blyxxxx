# Media Rights

![Magnificent frigatebird male](vendor/media_rights/assets/logo.png)

Track the expiry of a licensed asset and direct the host to withdraw an expired public copy.

Publishing and collaboration · framework · 0.1.2

Framework bird: Magnificent frigatebird male.

## Drive the workflow

Start with `media_rights_start()`. For each event call `media_rights_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `media_rights_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `media_rights_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | license | x>0 | cleared | record_expiry | x |
| cleared | publish | x<r | live | expose_asset | r |
| live | clock | x>=r | expired | withdraw_asset | r |
| live | extend | x>r | live | extend_license | x |
| expired | license | x>r | cleared | record_expiry | x |

Phase IDs in order from zero: idle, cleared, live, expired.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- license 50 publish 49 clock 50 license 60
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo media_rights@0.1.2
blyxc native-run media_rights-demo/main.blyx
```

Install with `nest add media_rights@0.1.2` and import `vendor::media_rights::media_rights`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
