# Inference Batch

![Indian paradise flycatcher male](vendor/inference_batch/assets/logo.png)

Seal variable-size inference requests by a token budget and carry the first oversized arrival to the next batch.

Machine learning and evaluation · framework · 0.1.2

Framework bird: Indian paradise flycatcher male.

## Drive the workflow

Start with `inference_batch_start()`. For each event call `inference_batch_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `inference_batch_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `inference_batch_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | budget | x>0 | packing | start_batch | x |
| packing | request | x>0 and x<=r | packing | enqueue_request | r-x |
| packing | request | x>r | rolling | execute_current | x |
| rolling | budget | x>=r | packing | enqueue_pending | x-r |
| rolling | budget | x<r | oversized | split_request | r |
| packing | flush | always | done | execute_current | r |

Phase IDs in order from zero: idle, packing, rolling, oversized, done.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- budget 8 request 6 request 5 budget 4
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo inference_batch@0.1.2
blyxc native-run inference_batch-demo/main.blyx
```

Install with `nest add inference_batch@0.1.2` and import `vendor::inference_batch::inference_batch`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
