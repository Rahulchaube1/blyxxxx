# Dock Appointments

![Red-billed tropicbird](vendor/dock_appointments/assets/logo.png)

Keep a loading bay available until its booked arrival time and account for late arrivals.

Logistics, utilities and production · framework · 0.1.2

Framework bird: Red-billed tropicbird.

## Drive the workflow

Start with `dock_appointments_start()`. For each event call `dock_appointments_step(snapshot, event, value)`, persist the returned snapshot, and dispatch `dock_appointments_command(snapshot)` to your application’s adapter. The host owns I/O, event ordering, duplicate detection and durable command delivery. A matching event produces one command. Rejected events retain the phase and saved quantity. An invalid snapshot yields an empty vector.

The snapshot contains phase ID, saved quantity and last command ID. Event values are whole numbers from zero through one billion. In the table, **x** is the event value and **r** is the saved quantity. Rules match in listed order. To validate a whole history without running effects use `dock_appointments_replay(events, values)`. It returns the final snapshot or an empty vector on rejection.

| Current phase | Event | Guard | Next phase | Command | New quantity |
|---|---|---|---|---|---|
| idle | book | x>0 | booked | reserve_dock | x |
| booked | arrive | x<=r | loading | admit_ontime | 0 |
| booked | arrive | x>r | loading | record_lateness | x-r |
| booked | cancel | always | idle | free_dock | 0 |
| loading | depart | always | idle | free_dock | 0 |

Phase IDs in order from zero: idle, booked, loading.

## Replay your own events

After installing the demo, run the following from its directory. Supply alternating event names and integer values. The command prints each requested action and exits with status 1 at the first rejected transition, or 2 for malformed arguments.

```sh
blyxc native-run main.blyx -- book 20 arrive 27 depart 0
```

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo dock_appointments@0.1.2
blyxc native-run dock_appointments-demo/main.blyx
```

Install with `nest add dock_appointments@0.1.2` and import `vendor::dock_appointments::dock_appointments`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
