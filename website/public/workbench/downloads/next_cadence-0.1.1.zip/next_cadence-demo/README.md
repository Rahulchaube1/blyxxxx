# Next Cadence

![Package logo](vendor/next_cadence/assets/logo.png)

Find the first cadence tick at or after a time, anchored to an initial tick. Period must be positive.

Calendar, time and scheduling · library · 0.1.1

## Function

```blyx
pub fn next_cadence(origin: i64, period: i64, time: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `5,10,16` | `25` |
| `5,10,15` | `15` |
| `5,10,0` | `5` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo next_cadence@0.1.1
blyxc native-run next_cadence-demo/main.blyx
```

Install with `nest add next_cadence@0.1.1` and import `vendor::next_cadence::next_cadence`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
