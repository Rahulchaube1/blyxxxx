# Uleb Width

![Package logo](vendor/uleb_width/assets/logo.png)

Determine the encoded byte length of a nonnegative integer in unsigned LEB128.

Data integrity, identifiers and formats · library · 0.1.1

## Function

```blyx
pub fn uleb_width(value: i64) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `127` | `1` |
| `16384` | `3` |
| `-1` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo uleb_width@0.1.1
blyxc native-run uleb_width-demo/main.blyx
```

Install with `nest add uleb_width@0.1.1` and import `vendor::uleb_width::uleb_width`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
