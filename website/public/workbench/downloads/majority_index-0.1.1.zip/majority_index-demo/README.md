# Majority Index

![Package logo](vendor/majority_index/assets/logo.png)

Find an index containing a strict majority using cancellation and a verification pass. Return minus one if none exists.

Sequence and table processing · library · 0.1.1

## Function

```blyx
pub fn majority_index(items: vector) -> i64
```

Use finite numeric values. Integer arithmetic assumes that intermediate results fit signed 64-bit storage. All indices are zero-based unless the contract above states otherwise.

| Inputs in declaration order | Expected result |
|---|---|
| `[7,7,2]` | `0` |
| `[1,2]` | `-1` |
| `[]` | `-1` |

## Run this checkout

Run `blyxc native-run main.blyx` to reproduce `expected.txt`. Run `blyxc native-run checks.blyx` and compare the complete output with `checks-expected.txt`.

## Try the published project

```sh
nest demo majority_index@0.1.1
blyxc native-run majority_index-demo/main.blyx
```

Install with `nest add majority_index@0.1.1` and import `vendor::majority_index::majority_index`.

Maintained by Rahul Chaube. [Blyx](https://www.blyx-lang.space) · [GitHub](https://github.com/Rahulchaube1) · [LinkedIn](https://www.linkedin.com/in/rahulchaube1) · [Sponsor](https://github.com/sponsors/Rahulchaube1)
