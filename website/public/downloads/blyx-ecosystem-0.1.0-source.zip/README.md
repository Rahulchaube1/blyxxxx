# Blyx workflow collection 0.1.0

Extract this archive into your project. The vendor directory contains 51 independently usable frameworks and 102 standalone library modules, with source, examples, licenses and tests. The manifest links each version to its own public repository and records the SHA-256 of the entry module. Frameworks include both of their library dependencies in their own directory.

Install the Blyx 0.2.1 compiler, Rust and a system linker for native builds. From the extracted directory:

    blyxc native-run example.blyx
    blyxc native-run vendor/avocet/tests.blyx
    blyxc native-run vendor/warbler/project.blyx -- "1,-1,0,0" 1 1
    blyxc build vendor/warbler/project.blyx -o warbler

On Windows add .exe to the executable name. Run a framework with --help for its positional arguments. The CLI supports 16 entries per vector argument. Write a Blyx program that imports the module to use longer inputs. Library imports are written as use vendor::clipruns::clipruns;. Use each package README for the result layout and inputs.

[Browse packages](https://www.blyx-lang.space/packages) · [Run examples](https://www.blyx-lang.space/play) · [Handbook](https://doc.blyx-lang.space/) · [Sponsor Blyx](https://www.blyx-lang.space/#sponsor)
