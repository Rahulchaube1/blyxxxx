Blyx framework logos

65 individual transparent PNGs, 320 by 320 pixels. Filenames match the framework slugs. Each artwork has a description and design brief in framework-logo-prompts.json.

Gallery: https://www.blyx-lang.space/frameworks/logos
Project: Rahul Chaube and the Blyx ecosystem
